<?php
 $pname=ucwords( str_ireplace(array('-', '.php'), array(' ', ''), basename($_SERVER['PHP_SELF']) ) );
 ?>
		<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!--meta info-->
		<meta name="author" content="">
		<meta name="keywords" content="">
		<meta name="description" content="">
		<!--include favicon-->
		<!--<link rel="shortcut icon" type="image/x-icon" href="images/fav.ico">-->
		<!--fonts include-->
		<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300,100' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,500,400italic,500italic,300italic,100italic,100,700italic,900,900italic,700' rel='stylesheet' type='text/css'>
		<!--stylesheet include-->
		<link rel="stylesheet" type="text/css" media="all" href="plugins/flexslider/flexslider.css">
		<link rel="stylesheet" type="text/css" media="all" href="plugins/fancybox/jquery.fancybox.css">
		<link rel="stylesheet" type="text/css" media="all" href="plugins/owl-carousel/assets/owl.carousel.min.css">
		<link rel="stylesheet" type="text/css" media="all" href="plugins/jackbox/css/jackbox.min.css">
		<link rel="stylesheet" type="text/css" media="all" href="css/animate.css">
		<link rel="stylesheet" type="text/css" media="all" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" media="all" href="css/style.css">
		
		<script src="js/jquery-2.1.1.min.js"></script>
		<script src="js/modernizr.js"></script>
		
		</head>
	<body class="sticky_menu">
		<!--<div id="preloader"></div>-->
		<!--layout-->
		<div class="wide_layout db_centered bg_white">
			<header role="banner" class="w_inherit">
				<div class="header_bottom_part bg_white type_2 t_sm_align_c w_inherit">
					<div class="container">
						<div class="d_table w_full d_xs_block">
							<div class="col-lg-2 col-md-2 d_sm_block w_sm_full d_table_cell d_xs_block f_none v_align_m m_xs_bottom_15">
								<a href="index.php" class="d_inline_b m_sm_top_5 m_sm_bottom_5 m_xs_bottom_0">
									<img src="images/logo.png" alt="">
								</a>
							</div>
							<div class="col-lg-5 col-md-5 d_sm_block w_sm_full d_table_cell d_xs_block f_none v_align_m">
								<div class="title">VPACK MACHINERY<br><span>MFG. LIQUID PACKAGING MACHINERY</span></div>
							</div>
							<div class="col-lg-5 col-md-5 d_sm_block w_sm_full d_table_cell d_xs_block f_none v_align_m">
								<button id="mobile_menu_button" class="vc_child d_xs_block db_xs_centered d_none m_bottom_10 m_top_15 bg_lbrown color_white tr_all"><i class="fa fa-navicon d_inline_m"></i></button>
								<nav role="navigation" class="d_xs_none t_sm_align_l d_sm_inline_b">
									<ul class="main_menu relative type_2 hr_list second_font fs_medium">
										<li <?php if($pname=="Index") { ?> class="current" <?php } ?> ><a href="index.php" class="tt_uppercase tr_delay">HOME</a></li>
										<li <?php if($pname=="About_us") { ?> class="current" <?php } ?> ><a href="about_us.php" class="tt_uppercase tr_delay">ABOUT US</a></li>
										<li <?php if($pname=="Category" || $pname=="Product") { ?> class="current" <?php } ?> >
											<a href="#" class="tt_uppercase tr_delay">PRODUCTS</a>
											<ul class="sub_menu bg_grey_light tr_all">
												<?php include('config.php');
													$sql="select * from category";
													$res=mysqli_query($conn,$sql);
													while($fatch=mysqli_fetch_array($res))
													{ ?>
												<?php $cn=$fatch['category_id']; ?>
												
												<li >
													<a href="category.php?scid=<?php echo $cn; ?>&&nam=<?php echo $fatch['category_name']; ?>"> <?php echo $fatch['category_name']; ?> </a>
												</li> 
												<?php } ?>
											</ul>
										</li>
										<li <?php if($pname=="Inquiry") { ?> class="current" <?php } ?>><a href="inquiry.php" class="tt_uppercase tr_delay">INQUIRY</a></li>
										<li <?php if($pname=="Contact_us") { ?> class="current" <?php } ?>><a href="contact_us.php" class="tt_uppercase tr_delay">CONTACT US</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
				<hr class="m_bottom_27 m_sm_bottom_10">
			</header>