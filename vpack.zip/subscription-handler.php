<?php
ob_start();
/**
 * File Name: subscription-handler.php
 *
 * Send message function to process contact form submission
 *
 */

if ( isset( $_POST['email'] ) ):

    $name = filter_var( $_POST['name'], FILTER_SANITIZE_STRING );
    $from_email = filter_var( $_POST['email'], FILTER_SANITIZE_EMAIL );

    $to_email = "sales@vpackmachinery.in";    // provide your target email address here
    $to_name = "vpackmachinery";

    $email_subject = 'Subscription Request From ' . $name . '.';

    if ( ! empty( $name ) ) {
        $email_subject = $name . '.';
    }

    $email_body = 	"You have Received a Subscription Request from: " . $name . " <br/>";

    $email_reply = 	"You can contact " . $name . " via email, " . $from_email ;

    $prepared_message = $email_body . $email_content . $email_reply;

    // You can consult https://github.com/eoghanobrien/php-simple-mail for more details
    require 'class.simple_mail.php';

    /* @var SimpleMail $mail */
    $mail = new SimpleMail();
    $mail->setTo( $to_email, $to_name )
        ->setSubject( $email_subject )
        ->setFrom( $from_email, $name )
        ->addMailHeader( 'Reply-To', $from_email, $name )
        ->addGenericHeader( 'X-Mailer', 'PHP/' . phpversion() )
        ->addGenericHeader( 'Content-Type', 'text/html; charset="utf-8"' )
        ->setMessage( $prepared_message );


    $sent = $mail->send();

  

    

else:

     json_encode(array(
            'success' => false,
            'message' => "Invalid Request !"
        )
    );
endif;
echo ("<script LANGUAGE='JavaScript'>
    window.alert('Your inuiry is Succesfully Send');
    window.location.href='index.php';
    </script>");
    die();
