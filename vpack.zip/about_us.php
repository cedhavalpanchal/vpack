<?php include('header.php');?>

	<!--breadcrumbs-->
	<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
		<div class="container">
			<a href="index.php" class="sc_hover">Home</a> / <span class="color_light">About Us</span>
		</div>
	</div>
	<!--main content-->
	<div class="page_section_offset">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 m_bottom_30 m_xs_bottom_10">
					<h2 class="fw_light second_font color_dark tt_uppercase m_bottom_20">About Us</h2>
					<hr class="divider_bg m_bottom_15">
						<div class="about">
							<p>We are pleased to introduce ourselves as engaged in manufacturing and marketing a wide range of machinery & equipments for pharmaceutical, food, cosmetics and chemical industries. The quality and proven performance of the machines manufactured by us and supplied to our valued customers has earned a good patronage. We strive for customer satisfaction with a reasonable price and quality machines is our motto. Our ambition is to grow with the upcoming pharma industry by enhancing our innovation and implementing new technologies to produce CGMP machines in India. So we would like to work closely with the pharma industry and to share our common experience and to frame appropriate machines under CGMP guidelines for India expeditiously.</p>
						</div><br>&nbsp;
							
					<div class="row">
						<main class="col-lg-4 col-md-4 col-sm-4 m_xs_bottom_20">
							<div class="about_img">
								<img src="images/main.jpg" >
							</div>
						</main>
						<section class="col-lg-8 col-md-8 col-sm-8">
							<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">QUALITY POLICY</h5>
							<hr class="divider_bg m_bottom_10">
							<div class="about">
								<p>At V-PACK, we will ensure quality in every aspect of business, including product, people or our response to customers. We will deliver products in time and will continuously improve our business process to meet the needs of our customers and work environment. We will continue to believe in teamwork to achieve the Right Quality, Timely Services and Excellent Workmanship.</p>
							</div><br>&nbsp;
							
							<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">VISION</h5>
							<hr class="divider_bg m_bottom_10">
							<div class="about">
								<p>To be a worldwide leader in pharmaceutical manufacturing technologies, especially in Liquid & Powder Packaging machinery Our reliability adds value to your purchase. The professionalism of the V-PACK team can help you to achieve your own best-in-class position by achieving higher speeds, faster changeovers and greater self impact. We not only build machines – we build confidence</p>
							</div>
						</section>
					</div>
				</div>
			</div>
		</div><br><br>
	</div>
			
<?php include('footer.php');?>