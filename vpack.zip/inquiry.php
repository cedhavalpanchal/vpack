<?php include('header.php');?>

			<!--breadcrumbs-->
			<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
				<div class="container">
					<a href="index.php" class="sc_hover">Home</a> / <span class="color_light">Contact</span>
				</div>
			</div>
			<!--main content-->
			<div class="page_section_offset">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 m_bottom_30 m_xs_bottom_10">
							<h2 class="fw_light second_font color_dark tt_uppercase m_bottom_10">INQUIRY NOW!</h2>
							<hr class="divider_bg m_bottom_30">
							<div class="row">
								<section class="col-lg-12 col-md-12 col-sm-12">
									<form id="appointment_form_main" action="enquiry_form_handler.php" method="post">
										<ul>
											<li class="row">
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_name">Name</label><br>
													<input type="text" name="name" id="app-name" class="tr_all w_full fw_light required" placeholder="" title="* Please provide your name"/>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_email">Phone Number</label><br>
													<input type="text" name="number" id="app-number" class="tr_all w_full fw_light required" placeholder="" title="* Please provide your phone number."/>
												</div>
											</li>
											<li class="row">
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_name">Email Address</label><br>
													<input type="email" name="email" id="app-email" class="tr_all w_full fw_light required email" placeholder="" title="* Please provide a valid email address"/>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													
												</div>
											</li>
											<li class="row">
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_name">Select Products</label><br>
													<select id="sub_category_id" class="required" name="pro_id">
														<option value="">--Select Product--</option>
														<?php include('config.php');
															$select_subcat = "select * from product order by product_id DESC";
															$res= mysqli_query($conn,$select_subcat);?>
															<?php	
																while($fetch = mysqli_fetch_array($res))
															{ ?>
																<option value="<?php echo $fetch['product_id']; ?>"><?php echo $fetch['product_name']; ?></option>
														<?php } ?>		
													</select> 
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_email">Company Name</label><br>
													<input type="text" name="company" id="com-name" class="tr_all w_full fw_light required" placeholder="" title="* Company Name"/>
													<!--<input type="number" name="numberofc" class="required" placeholder="" title="* Please provide your number of quantity."/>-->
												</div>
											</li>
											<li class="m_bottom_15">
												<label class="second_font d_inline_b m_bottom_5 clickable" for="cf_telephone">Message</label><br>
												<textarea name="message" id="app-message" class="tr_all w_full fw_light required" rows="4" cols="50" rows="1" placeholder="" title="* Please provide your message"></textarea>
											</li>
												<li>
												<button class="button_type_2 black state_2 tr_all second_font fs_medium tt_uppercase d_inline_b"><span class="m_left_10 m_right_10 d_inline_b">Submit</span></button>
											</li>
										</ul>
									</form>
								</section>
							</div>
						</div>
					</div>
				</div><br><br>
			</div>

<?php include('footer.php');?>