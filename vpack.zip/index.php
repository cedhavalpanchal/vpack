<?php include('header.php');?>
			
	<!--main content-->
	<div class="page_section_offset p_top_0"><br>
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-12 m_bottom_55 m_sm_bottom_30 animated hidden" data-animation="fadeInLeft" data-animation-delay="1250">
					<!--flexslider-->
					<div class="flexslider">
						<ul class="slides">
							<?php include('config.php');
							$sql= "select * from slider order by slider_id ASC";
							$res= mysqli_query($conn,$sql);
							while($fetch = mysqli_fetch_array($res))
									{
							?>
							<li>
								<img src="Back-vpack/<?php echo $fetch['image1'];?>" alt="<?php echo $fetch['product_name']; ?>" style="height: 560px;width:100%">
								<div class="flex_caption  d_xs_none t_align_r" style="right:100px;top:22%;">
									<p class="color_white fw_light tt_uppercase slider_fs_3 m_bottom_15">&nbsp;</p>
									<h1 class="color_white m_bottom_45 second_font tt_uppercase fw_thin slider_fs_4"><b><?php echo $fetch['title']; ?></b></h1>
									<!--<h5 class="d_inline_b d_xs_none button_type_5 bg_transparent slider_button color_white tt_uppercase fw_light fs_ex_large"><?php echo $fetch['desc']; ?></h5>-->
								</div>
							</li>
						 	<?php } ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 m_bottom_55 m_xs_bottom_50 t_sm_align_c">
					<!--banner-->
					<div class="animated hidden m_bottom_30" data-animation="fadeInLeft" data-animation-delay="1400">
						<figure class="relative wrapper scale_image_container d_sm_inline_b d_xs_block r_image_container">
							<img src="images/main.jpg" alt="" class="tr_all scale_image">
							<!--caption-->
						</figure>
					</div>
					<br>
					<!--banner-->
					<div class="banner_type_2 color_lbrown animated hidden" data-animation="fadeInLeft" data-animation-delay="1550">
						<div class="bg_lbrown inner color_white t_align_c">
							<h1 class="second_font fw_light m_bottom_10">Newsletter Sign Up</h1>
							<p class="fw_light m_bottom_15">Get exclusive deals you will not find anywhere else straight to your inbox!</p>
							<!--newsletter form-->
							<form action="subscription-handler.php">
                            	<input type="email" name="newsletter-email" class="" placeholder="Enter your email address">
								<button class="color_dark tr_all color_lbrown_hover"><i class="fa fa-envelope"></i></button>
							</form>
						</div>
					</div>
					
				</div>
			</div>

			<div class="row">
				<aside class="col-lg-3 col-md-3 col-sm-3">
					<!--categories widget-->
					<section class="m_bottom_30 animated hidden" data-animation="fadeInDown">
						<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">Categories</h5>
						<hr class="divider_bg m_bottom_23">
						
						<?php include('sidebar.php'); ?>
					</section>
				</aside>
				
				<main class="col-lg-9 col-md-9 col-sm-9">
					<h5 class="second_font color_dark tt_uppercase fw_light d_inline_m m_bottom_13 animated hidden" data-animation="fadeInDown">OUR VALUABLE Products</h5>
					
					<p class="notes">We strive for customer satisfaction with a reasonable price and quality machines is our motto. Our ambition is to grow with the upcoming pharma industry by enhancing our innovation and implementing new technologies to produce CGMP machines in India.</p><br>
					<hr class="divider_bg m_bottom_30 animated hidden" data-animation="fadeInDown" data-animation-delay="100">
					<?php
		            $sql= "select * from product where category_id=7";
		            $sql .= " order by product_id DESC LIMIT 3";
		           	$res= mysqli_query($conn,$sql);
		        	$rowCount = 0;
		        	$total = 0;
	        		if($res){
		        		$rowCount = mysqli_num_rows($res);
		        		$total = $rowCount;
		        	}
		        	if($rowCount > 0){
		            	$res = mysqli_query($conn,$sql);
		        	}
	       			if($rowCount < 1){
            			//No records in the table.
		            	echo "<strong> No Records Found !!! </strong> ";
		        	}else{
					while($fetch = mysqli_fetch_array($res))
                    {
		        	?>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 m_xs_bottom_30 m_bottom_40 animated hidden" data-animation="fadeInDown" data-animation-delay="200">
							<!--product-->
							<figure class="product_item type_2 c_image_container relative frame_container t_sm_align_c r_image_container qv_container">
								<!--image & buttons & label-->
								<div class="relative">
									<div class="pro_img">
										<img src="Back-vpack/<?php echo $fetch['image1']; ?>" alt="<?php echo $fetch['product_name']; ?>" class="c_image_1 tr_all">	
									</div>
								</div>
								<figcaption class="bg_white relative p_bottom_0">
									<div class="row">
										<div class="col-lg-12 col-md-12 m_bottom_9">
											<a class="second_font sc_hover d_xs_block big" href="product.php?pid=<?php echo $fetch['product_id']; ?>"><?php echo $fetch['product_name']; ?></a>	
										</div>
									</div>
									<!--<button data-popup="#add_to_cart_popup" data-popup-transition-in="bounceInUp" data-popup-transition-out="bounceOutUp" class="button_type_2 m_bottom_9 d_block w_full t_align_c lbrown state_2 tr_all second_font fs_medium tt_uppercase">VIEW DETAILS</button></a>-->	
								</figcaption>
							</figure>
							<div class="button">
								<a href="product.php?pid=<?php echo $fetch['product_id']; ?>">VIEW DETAILS</a>
							</div>
						</div>
 						<?php } } ?>
					</div>
					<!--brands carousel-->
					<section class="m_bottom_35 m_xs_bottom_30">
						<div class="d_table m_bottom_5 w_full animated hidden" data-animation="fadeInDown">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 v_align_m d_table_cell f_none">
								<h5 class="second_font color_dark tt_uppercase fw_light d_inline_m m_bottom_4">OUR VALUABLE CLIENTS</h5>	
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 t_align_r d_table_cell f_none">
								<!--carousel navigation-->
								<div class="clearfix d_inline_b">
									<button class="brands_carousel_prev black_hover button_type_4 grey state_2 tr_all d_block f_left vc_child m_right_5"><i class="fa fa-angle-left d_inline_m"></i></button>
									<button class="brands_carousel_next black_hover button_type_4 grey state_2 tr_all d_block f_left vc_child"><i class="fa fa-angle-right d_inline_m"></i></button>
								</div>
							</div>
						</div>
						<hr class="divider_bg m_bottom_15 animated hidden" data-animation="fadeInDown" data-animation-delay="100" />
						<!--carousel-->
						<div class="row">
							<div class="owl-carousel" data-nav="brands_carousel_" 
								data-owl-carousel-options='{
									"stagePadding" : 15,
									"margin" : 30,
									"responsive" : {
											"0" : {
												"items" : 2
											},
											"320" : {
												"items" : 3
											},
											"550" : {
												"items" : 4
											},
											"768" : {
												"items" : 4
											},
											"992" : {
												"items" : 5
											}
										}
									}'>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="200">
									<img src="images/client.jpg" alt="">
								</div>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="350">
									<img src="images/client.jpg" alt="">
								</div>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="500">
									<img src="images/client.jpg" alt="">
								</div>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="650">
									<img src="images/client.jpg" alt="">
								</div>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="800">
									<img src="images/client.jpg" alt="">
								</div>
								<div class="animated hidden" data-animation="fadeInDown" data-animation-delay="950">
									<img src="images/client.jpg" alt="">
								</div>
							</div>
						</div>
				</main>
			</div>
		</div>
	</div>
	
<?php include('footer.php');?>