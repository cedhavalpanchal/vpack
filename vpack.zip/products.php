<?php include('header.php');?>

	<!--breadcrumbs-->
	<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
		<div class="container">
			<a href="index.php" class="sc_hover">Home</a> / <span class="color_light">Products</span>
		</div>
	</div>
	<!--main content-->
	<div class="page_section_offset">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 m_bottom_30 m_xs_bottom_10">
					<div class="row">
						<main class="col-lg-3 col-md-3 col-sm-3 m_xs_bottom_20">
							<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">CATEGORies</h5>
							<hr class="divider_bg m_bottom_23">
							
							<?php include('sidebar.php'); ?>
						</main>

						<section class="col-lg-9 col-md-9 col-sm-9">
							<h5 class="fw_light second_font color_dark tt_uppercase m_bottom_13">OUR PRODUCTS</h5>
							<hr class="divider_bg m_bottom_25">

							<div class="products">
								<?php include('config.php');

					            $sql="select * from category";
					            $res=mysqli_query($conn,$sql);
					            while($fatch=mysqli_fetch_array($res))
					            { 
			            		?>

	                    		<?php $cn=$fatch['category_id']; 
								$fpr="select * from product where category_id='".$cn."'";
								$rpro=mysqli_query($conn,$fpr);
								$rproCount = 0;
							    $rprototal = 0;
							        
							    if($rpro){
							        $rproCount = mysqli_num_rows($rpro);
							        $rprototal = $rproCount;
							    }
							    if($rproCount > 0){
							        //$rpro = mysqli_query($conn,$rpro);
							    }
							    ?>
								<p class="main_category">
									<a href="category.php?scid=<?php echo $cn; ?>&&nam=<?php echo $fatch['category_name']; ?>" class="fs_large_0 d_inline_b"><i class="fa fa-arrows"></i><?php echo $fatch['category_name']; ?> </a>
									<?php if($rproCount > 0){  ?>
									<p class="sub_category">
										<?php while($fatch1=mysqli_fetch_array($rpro))
				            			{  ?>
										
										<a href="product.php?pid=<?php echo $fatch1['product_id']; ?>" class="tr_delay sc_hover bg_grey_light_2_hover"><i class="fa fa-arrow-right"></i><?php echo $fatch1['product_name']; ?><br></a><?php } ?>
									</p>
									<?php  } ?>
								</p>
								<?php } ?>
							</div>
						</section>
					</div>
				</div>
			</div>
		</div><br><br>
	</div>
			
<?php include('footer.php');?>