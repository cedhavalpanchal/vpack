			<!--footer-->
			<footer role="contentinfo" class="p_top_0">
				<div class="container">
					<div class="row m_bottom_13">
						<div class="col-lg-6 col-md-6">
							<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_13 m_sm_bottom_30">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_10">ABOUT US</h5>
									<hr class="divider_bg m_bottom_15">
									<p class="m_bottom_5">Our ambition is to grow with the upcoming pharma industry by enhancing our innovation and implementing new technologies to produce CGMP machines in India.</p>
									<p>So we would like to work closely with the pharma industry and to share our common experience and to frame appropriate machines under CGMP guidelines for India expeditiously.</p>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_13 m_sm_bottom_30">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_10">Contact us</h5>
									<hr class="divider_bg m_bottom_15">
									<p class="second_font m_bottom_5"><b>Address</b> :Plot No. 177, Radheshyam Industrial Estate, Opp. GVMM, S.P. Ring Road, Odhav, Ahmedabad - 382 415, <br>Gujarat. (INDIA)</p>
									<p class="second_font"><b>Phone</b> : (+91) 9558365525</p>
									<p class="second_font m_bottom_5" style="margin-left: 49px;">(+91) 90167 75450</p>
									<p class="second_font"><b>Email</b> : sales@vpackmachinery.in</p>
									<p class="second_font" style="margin-left: 47px;"></p>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6">
							<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_13 m_sm_bottom_30">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_10">Information</h5>
									<hr class="divider_bg m_bottom_15">
									<ul class="second_font vr_list_type_1 with_links">
										<li class="m_bottom_14"><a href="index.php" class="sc_hover d_inline_b"><i class="fa fa-caret-right"></i>HOME</a></li>
										<li class="m_bottom_14"><a href="about_us.php" class="sc_hover d_inline_b"><i class="fa fa-caret-right"></i>ABOUT US</a></li>
										<li class="m_bottom_14"><a href="products.php" class="sc_hover d_inline_b"><i class="fa fa-caret-right"></i>PRODUCTS</a></li>
										<li class="m_bottom_14"><a href="inquiry.php" class="sc_hover d_inline_b"><i class="fa fa-caret-right"></i>INQUIRY</a></li>
										<li class="m_bottom_14"><a href="contact_us.php" class="sc_hover d_inline_b"><i class="fa fa-caret-right"></i>CONTACT US</a></li>
									</ul>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_13 m_sm_bottom_30">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_10">FIND US ON MAP</h5>
									<hr class="divider_bg m_bottom_15">
									<div class="map">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.882230266561!2d72.67280131454605!3d23.028095984950255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e87081d553ff3%3A0x2083ac800395785f!2sV-PACK+MACHINERY!5e0!3m2!1sen!2sin!4v1522757199083" style="border:0"></iframe>
									</div>
								</div>
							</div>
						</div>
					</div>
					<hr class="divider_black m_bottom_13">
					<div class="d_table w_full d_xs_block t_xs_align_c">
						<div class="col-lg-12 col-md-12 col-sm-12 color_light fw_light f_none d_table_cell v_align_m d_xs_block m_xs_bottom_10" style="text-align: center;">
							&copy; Copyright 2018. "V-PACK MACHINERY" All Rights Reserved | Designed by <a href="www.sunitainfosys.com" style="color: #67c9e0" target="_blank">"Sunita Infosys"</a>
						</div>
					</div>
				</div>
			</footer>
		</div>

		<button class="back_to_top animated button_type_6 grey state_2 d_block black_hover f_left vc_child tr_all"><i class="fa fa-angle-up d_inline_m"></i></button>

		<script src="plugins/jquery.appear.js"></script>
		<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
		<script src="plugins/jackbox/js/jackbox-packed.min.js"></script>
		<script src="plugins/jquery.easytabs.min.js"></script>
		<script src="plugins/owl-carousel/owl.carousel.min.js"></script>
		<script src="plugins/twitter/jquery.tweet.min.js"></script><script src="plugins/flickr.js"></script>
		<script src="plugins/afterresize.min.js"></script>
		<script src="plugins/jquery.elevateZoom-3.0.8.min.js"></script>
		<script src="plugins/fancybox/jquery.fancybox.pack.js"></script>
		<script type="text/javascript" src="../../../s7.addthis.com/js/300/addthis_widget.js#pubid="></script>
		<script src="js/retina.min.js"></script>
		<script src="plugins/colorpicker/colorpicker.js"></script>
		<script src="js/styleswitcher.js"></script>
		<script src="js/themeCore.js"></script>
		<script src="js/theme.js"></script>
	</body>

</html>