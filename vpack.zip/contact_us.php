<?php include('header.php');?>

			<!--breadcrumbs-->
			<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
				<div class="container">
					<a href="index.php" class="sc_hover">Home</a> / <span class="color_light">Contact</span>
				</div>
			</div>
			<!--main content-->
			<div class="page_section_offset">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 m_bottom_30 m_xs_bottom_10">
							<h2 class="fw_light second_font color_dark tt_uppercase m_bottom_10">Our Location</h2>
							<hr class="divider_bg m_bottom_25">

							<div class="iframe_map_container m_bottom_38 m_xs_bottom_30">
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.882230266561!2d72.67280131454605!3d23.028095984950255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e87081d553ff3%3A0x2083ac800395785f!2sV-PACK+MACHINERY!5e0!3m2!1sen!2sin!4v1522757199083" style="border:0"></iframe>
							</div>
							<div class="row">
								<main class="col-lg-4 col-md-4 col-sm-4 m_xs_bottom_30">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_10">Contact Us</h5>
									<hr class="divider_bg m_bottom_15">
									<p class="second_font m_bottom_15"><b>Address</b> : Plot No. 177, Radheshyam Industrial<br>Estate, Opp. GVMM, S.P. Ring Road,<br> Odhav, Ahmedabad - 382415,<br> Gujarat. (INDIA)</p>
									<p class="second_font"><b>Phone</b> : (+91) 9558365525</p>
									<p class="second_font m_bottom_15" style="margin-left: 49px;">(+91) 90167 75450</p>
									<p class="second_font"><b>Email</b> : sales@vpackmachinery.in</p>
									<p class="second_font m_bottom_15" style="margin-left: 47px;"></p>
									<br>
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">Opening Hours</h5>
									<hr class="divider_bg m_bottom_10">
									<ul class="second_font">
										<li>Monday - Saturday : 08.00am - 9.00pm</li>
										<li>Sunday closed</li>
									</ul>
								</main>
								<section class="col-lg-8 col-md-8 col-sm-8">
									<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">Contact Form</h5>
									<hr class="divider_bg m_bottom_15">
									<form id="contact_form" class="contact-form" action="contact_form_handler.php" method="post">
										<ul>
											<li class="row">
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_name">Full Name</label><br>
													<input type="text" name="name" id="name" class="required" placeholder="" title="* Please provide your name">
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_15">
													<label class="second_font required d_inline_b m_bottom_5 clickable" for="cf_email">Email Address</label><br>
													<input type="text" name="email" id="email" class="required email" placeholder="" title="* Please provide a valid email address">
												</div>
											</li>
											<li class="m_bottom_15">
												<label class="second_font d_inline_b m_bottom_5 clickable" for="cf_telephone">Phone</label><br>
												<input type="text" name="number" id="number" placeholder="">
											</li>
											<li class="m_bottom_5">
												<label class="second_font d_inline_b m_bottom_5 clickable" for="cf_message">Message</label><br>
												<textarea name="message" id="message" class="required" cols="30" rows="6"  placeholder="" title="* Please provide your message"></textarea>
											</li>
											<li>
												<button class="button_type_2 black state_2 tr_all second_font fs_medium tt_uppercase d_inline_b"><span class="m_left_10 m_right_10 d_inline_b">Submit</span></button>
											</li>
										</ul>
									</form>
								</section>
							</div>
						</div>
					</div>
				</div><br><br>
			</div>

<?php include('footer.php');?>