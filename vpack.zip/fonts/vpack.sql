-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2018 at 02:45 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vpack`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE `aboutus` (
  `abt_id` int(11) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brocher`
--

CREATE TABLE `brocher` (
  `brocher_id` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `file_upload` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(13) NOT NULL,
  `category_name` varchar(200) NOT NULL,
  `status` int(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `status`) VALUES
(1, 'Bottel Washing Machine', 0),
(2, 'Cleaning Machine', 0),
(3, 'Filling Machine', 0),
(4, 'Capping Machine', 0),
(5, 'Labeling Machine', 0),
(6, 'Powder Filling Machine', 0),
(7, 'Blocks', 0),
(8, 'Other Accessories ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `email` int(11) NOT NULL,
  `contactno` int(11) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallary`
--

CREATE TABLE `gallary` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallary`
--

INSERT INTO `gallary` (`id`, `image`) VALUES
(1, 'gallaryimage/gallary_id1image1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `inquiry_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `message` text NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `Model_id` int(11) NOT NULL,
  `model_name` varchar(200) NOT NULL,
  `model_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `offer_id` int(11) NOT NULL,
  `images` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `unitprice` varchar(200) NOT NULL,
  `moq` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(13) NOT NULL,
  `category_id` int(13) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `image1` varchar(200) NOT NULL,
  `product_description` longtext NOT NULL,
  `Features` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `category_id`, `product_name`, `image1`, `product_description`, `Features`) VALUES
(1, 1, 'Automatic Rotary Bottle Washing Machine', 'productimage/pro_id1image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<caption>Product Description</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Model</strong></td>\r\n			<td><strong>VPM/WM-64</strong></td>\r\n			<td><strong>VPM/WM-96</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Output/Hour*</td>\r\n			<td>2600 to 6000 nos.</td>\r\n			<td>4300 to 9000 nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No. of Container Holder</td>\r\n			<td>64</td>\r\n			<td>96</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Main Motor</td>\r\n			<td colspan=\"2\" rowspan=\"1\">0.5 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pump Two Nos.</td>\r\n			<td colspan=\"2\" rowspan=\"1\">1 HP X 2 = 2 HP / 415 Volts / 50 Hz</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Electric Heater</td>\r\n			<td colspan=\"2\" rowspan=\"1\">3 Kw.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tank Capacity</td>\r\n			<td colspan=\"2\" rowspan=\"1\">75 Ltrs. S.S. 304 (2 Nos.)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wash Cycle</td>\r\n			<td colspan=\"2\" rowspan=\"1\">4 Inner+1 Outer</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px; text-align:justify; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left\">Model</td>\r\n			<td style=\"text-align:left\">DRWM - 64</td>\r\n			<td style=\"text-align:left\">DRWM - 96</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Output / Hour*</strong></td>\r\n			<td style=\"text-align:left\">2600 to 6000 Nos.</td>\r\n			<td style=\"text-align:left\">4300 to 9000 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>No. of Container Holder</strong></td>\r\n			<td style=\"text-align:left\">64</td>\r\n			<td style=\"text-align:left\">96</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Direction of Machine**</strong></td>\r\n			<td colspan=\"2\" style=\"text-align:left\">Clock wise</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"3\" style=\"text-align:left\"><strong>Electrical Specification**</strong>\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td>Main Motor</td>\r\n						<td>0.5 HP / 415 Volts / 50 Hz</td>\r\n					</tr>\r\n					<tr>\r\n						<td>Pumps</td>\r\n						<td>1 HP / 415 Volts / 50 Hz 2 Nos.</td>\r\n					</tr>\r\n					<tr>\r\n						<td>Electrical Heater</td>\r\n						<td>3 Kw.</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Tank Capacity</strong></td>\r\n			<td colspan=\"2\" style=\"text-align:left\">75 Ltrs. S.S. 304 (2 Nos.)</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Wash Cycle</strong></td>\r\n			<td colspan=\"2\" style=\"text-align:left\">4 Inner + 1 Outer</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Working Height</strong></td>\r\n			<td colspan=\"2\" style=\"text-align:left\">860 to 910 mm</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong>Salient Features</strong></p>\r\n\r\n<ul>\r\n	<li>Geneva Mechanism Four Inner (Included one air wash) &amp; one outer</li>\r\n	<li>Sequence of washes to customer&#39;s choice Easy operation</li>\r\n</ul>\r\n'),
(2, 1, 'Automatic Linear Bottle Washing Machine', 'productimage/pro_id2image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<caption>Product Description</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Model</strong></td>\r\n			<td>&nbsp;</td>\r\n			<td><strong>VPM/LWM-10</strong></td>\r\n			<td><strong>VPM/LWM-12</strong></td>\r\n			<td><strong>VPM/LWM-16</strong></td>\r\n			<td><strong>VPM/LWM-20</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Output/Hour*</td>\r\n			<td>&nbsp;</td>\r\n			<td>6000 Bottles</td>\r\n			<td>9000 Bottles</td>\r\n			<td>12000 Bottles</td>\r\n			<td>14000 Bottles</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No. of Pocket Across</td>\r\n			<td>&nbsp;</td>\r\n			<td>10</td>\r\n			<td>12</td>\r\n			<td>16</td>\r\n			<td>20</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"1\" rowspan=\"3\">Electrical<br />\r\n			Specification**</td>\r\n			<td>Main<br />\r\n			Motor</td>\r\n			<td>1 HP / 415<br />\r\n			Volts / 50 Hz</td>\r\n			<td>1 HP / 415<br />\r\n			Volts / 50 Hz</td>\r\n			<td>1 HP / 415<br />\r\n			Volts / 50 Hz</td>\r\n			<td>1 HP / 415<br />\r\n			Volts / 50 Hz</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pump<br />\r\n			Two Nos.</td>\r\n			<td>1 HP X 2 = 2 HP /<br />\r\n			415 Volts / 50 Hz</td>\r\n			<td>1 HP X 2 = 2 HP /<br />\r\n			415 Volts / 50 Hz</td>\r\n			<td>1 HP X 2 = 2 HP /<br />\r\n			415 Volts / 50 Hz</td>\r\n			<td>1 HP X 2 = 2 HP /<br />\r\n			415 Volts / 50 Hz</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Electrical<br />\r\n			Heater</td>\r\n			<td>3 Kw.</td>\r\n			<td>3 Kw.</td>\r\n			<td>3 Kw.</td>\r\n			<td>3 Kw.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><span style=\"font-size:20px\"><strong>Salient Features</strong></span></p>\r\n\r\n<ul>\r\n	<li>High-pressure spray nozzles ensure perfect wash of Bottle Interchangeable wash sequence</li>\r\n	<li>Totally fabricated from SS Materials, including the basic frame No change parts required for washing</li>\r\n	<li>of round bottle saving time of change over. (Change parts require for bottles &amp; if change of neck size.)</li>\r\n</ul>\r\n'),
(3, 2, 'Automatic Air jet Cleaning Machine (Inverter Type)', 'productimage/pro_id3image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Model</strong></td>\r\n			<td><strong>VPM/AJC-I</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Output / Hour*</td>\r\n			<td>2400 to 7200 Container</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Direction of Movement</td>\r\n			<td>Left to Right</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Electrical Specification**</td>\r\n			<td>\r\n			<p>0.5 HP / 415 Volts / 50 Hz.</p>\r\n\r\n			<p>0.5 HP x 2 = 2 HP / 415 Volts / 50 HZ</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Cleaning Cycle</td>\r\n			<td>Positive air pressure and vacuum cleaning</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong><span style=\"font-size:20px\">Salient Features</span></strong></p>\r\n\r\n<ul>\r\n	<li>Positive air pressure and vacuum cleaning</li>\r\n	<li>Easy operation Stationary S.S. nozzles</li>\r\n	<li>Automatic loading and unloading of container</li>\r\n</ul>\r\n'),
(4, 2, 'Automatic Vertical Air Jet Cleaning Machine', 'productimage/pro_id4image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<caption>Product Description</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\" rowspan=\"1\"><strong>Model</strong></td>\r\n			<td><strong>VPM/AJC-4V</strong></td>\r\n			<td><strong>VPM/AJC-6V</strong></td>\r\n			<td><strong>VPM/AJC-8V</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" rowspan=\"1\">Output/Hour*</td>\r\n			<td>1000 to 5000</td>\r\n			<td>2400 to 7200</td>\r\n			<td>6000 to 9000</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" rowspan=\"1\">No. of Cleaning Nozzles</td>\r\n			<td>4</td>\r\n			<td>6</td>\r\n			<td>8</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"1\" rowspan=\"2\">Electrical<br />\r\n			Specification**</td>\r\n			<td>Converyor</td>\r\n			<td>0.5 HP / 415<br />\r\n			Volts/ 50 HZ</td>\r\n			<td>0.5 HP / 415<br />\r\n			Volts/ 50 HZ</td>\r\n			<td>0.5 HP / 415<br />\r\n			Volts/ 50 HZ</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Vacuum<br />\r\n			Blower</td>\r\n			<td>0.5 HP</td>\r\n			<td>1 HP</td>\r\n			<td>1.5 HP</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><span style=\"font-size:20px\"><strong>Salient Features</strong></span></p>\r\n\r\n<ul>\r\n	<li>Positive air pressure and vacuum cleaning Easy operation</li>\r\n	<li>Adjustable &amp; diving type cleaning nozzles</li>\r\n	<li>Individual control air pressure and vacuum cleaning</li>\r\n</ul>\r\n'),
(5, 3, 'Automatic Volumetric Liquid Filling Machine', 'productimage/pro_id5image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<caption>Product Description</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Model</strong></td>\r\n			<td><strong>VPM/LF-4</strong></td>\r\n			<td><strong>VPM/LF-6</strong></td>\r\n			<td><strong>VPM/LF-8</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Output/Hour*</td>\r\n			<td>2400 to 6000*</td>\r\n			<td>3600 to 9000*</td>\r\n			<td>5000 to 12000*</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Direction of Movement</td>\r\n			<td>Left to Right</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Number of Movement</td>\r\n			<td>4 Nos.</td>\r\n			<td>6 Nos.</td>\r\n			<td>8 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Fill Size**</td>\r\n			<td colspan=\"3\" rowspan=\"1\">5 ml to 1000 ml</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\">Electrical Specification</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Main Machine</td>\r\n			<td>1 HP / 415 Volts / 50 Hz.<br />\r\n			(1.5 HP if maximum volume is<br />\r\n			1000 ml in single doze)</td>\r\n			<td colspan=\"2\">1 HP / 415 Volts / 50 Hz.<br />\r\n			(1.5 HP if maximum volume is<br />\r\n			1000 ml in single doze)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Main Machine</td>\r\n			<td colspan=\"3\" rowspan=\"1\">0.5 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', ''),
(6, 3, 'Automatic Viscous Filling Machine', 'productimage/pro_id6image1.jpg', '<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"6\" style=\"height:24px; width:435px\">\r\n			<p style=\"margin-left:80.3pt\"><strong>Automatic Viscous Filling Machine</strong></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"height:21px; width:138px\">\r\n			<p style=\"margin-left:36.1pt\"><strong>Model</strong></p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.0pt\"><strong>VPM/VFL-2</strong></p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.2pt\"><strong>VPM/VFL-4</strong></p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.05pt\"><strong>VPM/VFL-6</strong></p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.1pt\"><strong>VPM/VFL-8</strong></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"height:21px; width:138px\">\r\n			<p style=\"margin-left:28.1pt\">Output/Hour*</p>\r\n			</td>\r\n			<td colspan=\"4\" style=\"height:21px; width:296px\">\r\n			<p style=\"margin-left:1.4pt\">Up to 3000 Nos. Up to 5000 Nos. Up to 7200 Nos. Up to 9000 Nos.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"height:21px; width:138px\">\r\n			<p style=\"margin-left:13.25pt\">Direction of Movement</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.35pt\">Left to Right</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.5pt\">Left to Right</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.05pt\">Left to Right</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.1pt\">Left to Right</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"height:21px; width:138px\">\r\n			<p style=\"margin-left:10.4pt\">Number of head/Nozzle</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.35pt\">2 Nozzles</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:3.1pt\">4 Nozzles</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.05pt\">6 Nozzles</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.1pt\">8 Nozzles</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"height:21px; width:138px\">\r\n			<p style=\"margin-left:36.1pt\">Fill Size</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p>5 ml to 1000 ml</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p>5 ml to 1000 ml</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.05pt\">5 ml to 1000 ml</p>\r\n			</td>\r\n			<td style=\"height:21px; width:74px\">\r\n			<p style=\"margin-left:.1pt\">5 ml to 1000 ml</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\" style=\"height:37px; width:94px\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p style=\"margin-left:9.35pt\">Electrical Specification**</p>\r\n			</td>\r\n			<td style=\"height:37px; width:44px\">\r\n			<p style=\"margin-left:3.25pt\">Filling Section</p>\r\n			</td>\r\n			<td colspan=\"4\" style=\"height:37px; width:296px\">\r\n			<p style=\"margin-left:1.15pt\">0.7 KW/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0.7 KW /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0.7 KW /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0.7 KW /</p>\r\n\r\n			<p style=\"margin-left:.1pt\">415 Volts /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 415 Volts /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 415 Volts /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 415 Volts /</p>\r\n\r\n			<p style=\"margin-left:.1pt\">50 Hz. x 2 Nos. 50 Hz. x 4 Nos. 50 Hz. x 6 Nos. 50 Hz. x 8 Nos.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:37px; width:44px\">\r\n			<p style=\"margin-left:1.05pt\">Conveyor</p>\r\n			</td>\r\n			<td style=\"height:37px; width:74px\">\r\n			<p style=\"margin-left:9.75pt\">0.5 HP / 415 Volts /</p>\r\n\r\n			<p style=\"margin-left:16.7pt\">50 Hz.</p>\r\n			</td>\r\n			<td style=\"height:37px; width:74px\">\r\n			<p style=\"margin-left:9.85pt\">0.5 HP / 415 Volts /</p>\r\n\r\n			<p style=\"margin-left:16.8pt\">50 Hz.</p>\r\n			</td>\r\n			<td style=\"height:37px; width:74px\">\r\n			<p style=\"margin-left:9.9pt\">0.5 HP / 415 Volts /</p>\r\n\r\n			<p style=\"margin-left:16.85pt\">50 Hz.</p>\r\n			</td>\r\n			<td style=\"height:37px; width:74px\">\r\n			<p style=\"margin-left:12.1pt\">0.5 HP / 415 Volts</p>\r\n\r\n			<p style=\"margin-left:16.85pt\">50 Hz.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:37px; width:44px\">\r\n			<p style=\"margin-left:9.9pt\">Height of Conveyor**</p>\r\n			</td>\r\n			<td colspan=\"4\" rowspan=\"1\" style=\"height:37px; width:74px\">\r\n			<p style=\"margin-left:67.35pt\">860 to 910 mm Adjustable</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', ''),
(7, 3, 'Automatic Pressure Over Flow Filling Machine', 'productimage/pro_id7image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\"><strong>Model</strong></td>\r\n			<td><strong>VPM/POFL-2&nbsp;</strong></td>\r\n			<td><strong>VPM/POFL-4</strong></td>\r\n			<td><strong>VPM/POFL-6</strong></td>\r\n			<td><strong>VPM/POFL-8</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n			<p>Output/Hour*</p>\r\n			</td>\r\n			<td>\r\n			<p>1000 -2400</p>\r\n\r\n			<p>bottles (200 to bottles&nbsp;1000 ml.)</p>\r\n			</td>\r\n			<td>\r\n			<p>&nbsp;&nbsp;3600 -2400</p>\r\n\r\n			<p>bottles (200 to bottles&nbsp;1000 ml.)</p>\r\n			</td>\r\n			<td>\r\n			<p>4000 -3000</p>\r\n\r\n			<p>bottles (200 to bottles&nbsp;1000 ml.)</p>\r\n			</td>\r\n			<td>\r\n			<p>&nbsp;6000 -3600</p>\r\n\r\n			<p>bottles (200 to bottles&nbsp;1000 ml.)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">Direction of Movement</td>\r\n			<td colspan=\"4\" rowspan=\"1\">Left to Right</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">Number of Filling Head</td>\r\n			<td rowspan=\"1\">2 Nos.</td>\r\n			<td rowspan=\"1\">4 Nos.</td>\r\n			<td rowspan=\"1\">6 Nos.</td>\r\n			<td rowspan=\"1\">8 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\">Electrical<br />\r\n			Specification**</td>\r\n			<td>Infeed<br />\r\n			Conveyor<br />\r\n			Motor</td>\r\n			<td colspan=\"4\">0.5 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Centrifugal<br />\r\n			Pump</td>\r\n			<td colspan=\"4\">1 HP</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">Height of Conveyor**</td>\r\n			<td colspan=\"4\" rowspan=\"1\">860 mm to 910 mm</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '<p><span style=\"font-size:20px\"><strong>Salient Features</strong></span></p>\r\n\r\n<ul>\r\n	<li>&plusmn; 1% Filling accuracy on single dose (Depend on</li>\r\n	<li>container volume) Nozzle spacing fully Adjustable</li>\r\n	<li>through top crew Suitable for glass, plastic, metal</li>\r\n	<li>containers No change parts needed for various</li>\r\n	<li>types of containers No Bottle No Filling System</li>\r\n	<li>Sanitary Stainless Steel fill nozzle</li>\r\n	<li>SS food grade manifold with tri-clover connection</li>\r\n</ul>\r\n'),
(8, 3, 'Semi Piston Type Filling Machine', 'productimage/pro_id8image1.jpg', '', ''),
(9, 3, 'Semi Liquid Filling Machine', 'productimage/pro_id9image1.jpg', '', ''),
(30, 3, 'Semi Pressure Over Flow Filling Machine', 'productimage/pro_id30image1.jpg', '', ''),
(31, 4, 'Single Head ROPP Cap Sealing Machine', 'productimage/pro_id31image1.jpg', '', ''),
(32, 4, 'Single Head Screw Capping Machine', 'productimage/pro_id32image1.jpg', '', ''),
(10, 3, 'FLOAT TANK', 'productimage/pro_id10image1.jpg', '<p>Float Tank capacity 150 Ltrs. / 18 Gauge SS 316 Mirror<br />\r\nFinished with float controlled valve, drain outlet ball valve,<br />\r\noutlet suitable PVC tubing troug triclover type type manifold<br />\r\nand castor wheel (Available in highercapacity volume models.</p>\r\n', ''),
(11, 4, 'Automatic Multi Head ROPP Cap Sealing Machine', 'productimage/pro_id11image1.jpg', '<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px; text-align:justify; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left\"><strong><span style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px\">VPM/ROPP-1</span></strong></td>\r\n			<td style=\"text-align:left\"><strong>VPM/ROPP-4</strong></td>\r\n			<td style=\"text-align:left\"><strong><span style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px\">VPM/ROPP-6</span></strong></td>\r\n			<td style=\"text-align:left\"><strong><span style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px\">VPM/ROPP-8</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Output / Hour*</strong></td>\r\n			<td style=\"text-align:left\"><span style=\"color:rgb(78, 78, 78); font-family:verdana,arial,helvetica,sans-serif; font-size:11px\">1000 to 3600 bottles.</span></td>\r\n			<td style=\"text-align:left\">3600 to 6000 bottles.</td>\r\n			<td style=\"text-align:left\">3600 to 9000 bottles.</td>\r\n			<td style=\"text-align:left\">4000 to 12000 bottles.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left\"><strong>Number of head</strong></td>\r\n			<td style=\"text-align:left\">1 Nos.</td>\r\n			<td style=\"text-align:left\">4 Nos.</td>\r\n			<td style=\"text-align:left\">6 Nos.</td>\r\n			<td style=\"text-align:left\">8 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"5\" style=\"text-align:left\"><strong>Electrical Specification**</strong>\r\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td>Main Motor</td>\r\n						<td>1.5 HP / 415 Volts / 50Hz.</td>\r\n					</tr>\r\n					<tr>\r\n						<td>Cap Feeding Bowl</td>\r\n						<td>0.25 HP / 415 Volts / 50 Hz.</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n', ''),
(12, 4, 'Automatic Multi Head Screw Capping Machine', 'productimage/pro_id12image1.jpg', '<p>â€‹</p>\r\n\r\n<table border=\"0\" style=\"border-collapse:collapse; font-family:arial,helvetica,sans-serif; font-size:17px; margin:0px; padding:0px; width:443px\">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Model</strong></td>\r\n			<td><strong>VPM/SC-1</strong></td>\r\n			<td><strong>VPM/SC-4</strong></td>\r\n			<td><strong>VPM/SC-6</strong></td>\r\n			<td><strong>VPM/SC-8</strong></td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Output/Hour*</td>\r\n			<td>1200 to 2400<br />\r\n			Bottles.</td>\r\n			<td>3600 to 6000<br />\r\n			Bottles.</td>\r\n			<td>3600 to 9000<br />\r\n			Bottles.</td>\r\n			<td>4000 to 12000<br />\r\n			Bottles.</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No Of Sealing Head</td>\r\n			<td>1 Nos.</td>\r\n			<td>4 Nos.</td>\r\n			<td>6 Nos.</td>\r\n			<td>8 Nos.</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\">Electric<br />\r\n			Specification**</td>\r\n			<td>Main<br />\r\n			Motor</td>\r\n			<td>1 HP / 415 Volts / 50 Hz.</td>\r\n			<td>1.5 HP / 415 Volts / 50 Hz.</td>\r\n			<td>2 HP / 415 Volts / 50 Hz.</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Cap Feeding<br />\r\n			Bowl</td>\r\n			<td colspan=\"4\">3000 Watt, Magnetic Coil</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', ''),
(13, 4, 'Automatic Dosing Cup Placement & Processing Machine', 'productimage/pro_id13image1.jpg', '<p><strong>Technical Specification:</strong><br />\r\n&nbsp;</p>\r\n\r\n<table border=\"0\" style=\"border-collapse:collapse; font-family:arial,helvetica,sans-serif; font-size:17px; margin:0px; padding:0px; width:443px\">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong><span style=\"font-size:13px\">Model</span></strong></td>\r\n			<td>&nbsp;</td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/DCP-L</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Output/Hour*</span></td>\r\n			<td>&nbsp;</td>\r\n			<td>6000 to 12000 bottles&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\"><span style=\"font-size:13px\">No Of Groove</span></td>\r\n			<td><span style=\"font-size:13px\">6 Nos.</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\"><span style=\"font-size:13px\">Electric<br />\r\n			Specification**</span></td>\r\n			<td><span style=\"font-size:13px\">Conveyor<br />\r\n			Motor</span></td>\r\n			<td>0.5 HP / 415 Volts / 50 Hz&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Processing Motor</span></td>\r\n			<td><span style=\"font-size:13px\">90 Watt Magnetic Coil</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', ''),
(14, 0, 'Semi Automatic Screw Capping Machine', 'productimage/pro_id14image1.jpg', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>VPM/SC-1â€‹</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Output/Hour* 1000 TO 2400 Containers</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">No Of Sealing Head 1 Nos.</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Electric Motor** 1 HP / 440 Volts / 3 Phase / 50 Hz<br />\r\n(Four Wire) For Main Machine</p>\r\n', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>Salient Features:</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">&bull; No container no cup arrangement<br />\r\n&bull; SS elegantly matt finished body<br />\r\n&bull; Single motor synchronizes conveyor, star wheel, &amp; platform turret<br />\r\n&bull; Adjustable height of conveyor belt, to align with other machine of the line<br />\r\n&bull; Specially designed hopper is provided to increase storage capacity of bowl<br />\r\n&bull; Low noise level, low power consumptions</p>\r\n'),
(15, 4, 'Semi Automatic Ropp Cap Sealing Machine', 'productimage/pro_id15image1.jpg', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>Technical Specification:</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\"><strong>VPM/ROPP-1</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Output/Hour* 1000 TO 2400 Containers</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">No Of Sealing Head 1 Nos.</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Electric Motor** 0.5&nbsp;HP / 440 Volts / 3 Phase / 50 Hz<br />\r\n(Four Wire) For Main Machine&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', ''),
(16, 4, 'Semi Automatic Screw Capping Machine', 'productimage/pro_id16image1.jpg', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>Technical Specification:</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\"><strong>Model</strong> <strong>VPM/SC-1</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Output/Hour* 1000 TO 2400 Containers</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">No Of Sealing Head 1 Nos.</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Electric Motor** 0.5&nbsp;HP / 440 Volts / 3 Phase / 50 Hz<br />\r\n(Four Wire) For Main Machine</p>\r\n\r\n<p>&quot;</p>\r\n', ''),
(17, 5, 'Gum Labeling Machine', 'productimage/pro_id17image1.jpg', '<p><strong>Technical Specification:</strong><br />\r\n&nbsp;</p>\r\n\r\n<div class=\"t2\" id=\"add_t2_2\" style=\"margin: 0px; padding: 0px 17px 0px 0px; max-width: 100%; color: rgb(96, 96, 96); font-family: Arial, Helvetica, sans-serif; font-size: 17px; text-align: justify; overflow-x: auto !important;\">\r\n<table border=\"0\" style=\"border-collapse:collapse\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/GL</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\">Output/Hour</td>\r\n			<td style=\"text-align:left; vertical-align:top\">3600 to 9000 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Electrical</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Main Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.75 HP, 415 Volts, 50 Hz</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Specification</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Vaccum Pump</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.5 HP, 415 Volts, 50 Hz</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p>Salient Features<br />\r\nStainless steel cladding or hard chrome plating of all exposed parts<br />\r\nto ensure long life and resistance against corrosion<br />\r\nAdjustable Conveyor Height to align with other machine of the line<br />\r\nMinimum changeover time is required from one size of container or label to another</p>\r\n'),
(18, 5, 'Self Adhesive Sticker Labeling Machine (For round Container)', 'productimage/pro_id18image1.jpg', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>Technical Specification:</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\"><strong>Model VPM/SL-R</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Output/Hour 3600 to 9000</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Electrical Conveyor 0.50 HP, 240 Volts, 50 Hz</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Specification Pressing Device Motor 0.25 HP, 240 Volts, 50 Hz</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Stroller Roll Stepper Moter 1 HP&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p>Salient Features<br />\r\nHigh Product Speeds<br />\r\nsteel 304 sheet GMP norms PLC Based operation<br />\r\nAccurate label placement Product data storage facility<br />\r\nNo Change Part&#39;s Required</p>\r\n'),
(19, 5, 'Self Adhesive Sticker Labeling Machine (For Flat Container)', 'productimage/pro_id19image1.jpg', '<p dir=\"ltr\" style=\"text-align:justify\"><strong>Technical Specification:</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\"><strong>Model VPM/SL-F</strong></p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Output/Hour 3600 to 9000 Nos.</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Electrical Conveyor 0.25&nbsp;HP, 230 Volts, 50 Hz</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Top Bottle Guide Belt&nbsp;90 Watt, Gear Motor</p>\r\n\r\n<p dir=\"ltr\" style=\"text-align:justify\">Stroller Roll Stepper Moter 400 watt. x 2 Nos.</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong>Salient Features</strong></p>\r\n\r\n<ul>\r\n	<li>High Product Speeds</li>\r\n	<li>Container hold from top perfect &amp; accurate labeling GMP Design</li>\r\n	<li>Accurate label placement Full Security Package including Counter</li>\r\n</ul>\r\n'),
(20, 5, 'Semi Automatic Labeling Machine', 'productimage/pro_id20image1.jpg', '', ''),
(33, 6, 'Semi Automatic Powder Filling Machine', 'productimage/pro_id33image1.jpg', '<p>&quot;</p>\r\n', ''),
(34, 4, ' Semi Automatic Self Adhesive Labeling Machine', 'productimage/pro_id34image1.jpg', '', ''),
(21, 6, 'Two Head Powder Filling Machine', 'productimage/pro_id21image1.jpg', '<div class=\"t2\" id=\"add_t2_1\" style=\"margin: 0px; padding: 0px 17px 0px 0px; max-width: 100%; color: rgb(96, 96, 96); font-family: Arial, Helvetica, sans-serif; font-size: 17px; text-align: justify; overflow-x: auto !important;\">\r\n<table border=\"0\" style=\"border-collapse:collapse\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/PF-1</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/PF-2</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Output/Minute*</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1200 to 1800<br />\r\n			(UP to 25 gms Filling Size)<br />\r\n			800 to 1200<br />\r\n			(Above 25 gms Filling Size)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2400 to 3600<br />\r\n			(UP to 25 gms Filling Size)<br />\r\n			1200to 2400<br />\r\n			(Above 25 gms Filling Size)</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Direction of Movement</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Left to Right</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Left to Right</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Number of Filling Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1 Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2 Head</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Electrical Specification**</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Main Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.5 HP / 415 Volts /&nbsp; Hz</td>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px\">0.5 HP / 415 Volts /Hz</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Conveyor Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.5 HP / 415 Volts / Hz</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.5 HP / 415 Volts / Hz</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Servo Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">750 Watt</td>\r\n			<td style=\"text-align:left; vertical-align:top\">750 Watt -2 Nos</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Air Consumption</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4 &ndash; 6 Kg. Pressure</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4 &ndash; 6 Kg. Pressure</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong>Salient Features:</strong><br />\r\n&nbsp;</p>\r\n\r\n<ul>\r\n	<li>&plusmn; 2 %Filling accuracy on single dose</li>\r\n	<li>All Contact Parts in SS 316</li>\r\n	<li>Adjustable height of Conveyor Belt</li>\r\n	<li>Low Noise Level, Low Power Consumptions</li>\r\n	<li>NB: Above Models are available in Clutch &amp;Timer based operation</li>\r\n</ul>\r\n'),
(22, 6, 'Automatic Rotary Powder Filling Machine', 'productimage/pro_id22image1.jpg', '<table border=\"1\" style=\"border-collapse:collapse; font-family:arial,helvetica,sans-serif; font-size:17px; margin:0px; padding:0px; width:443px\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"5\">\r\n			<p><span style=\"font-size:13px\">Technical Specifications</span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\"><strong>Model</strong></td>\r\n			<td><strong>VPM/PF-R</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><span style=\"font-size:13px\">Output/Hour*</span></p>\r\n			</td>\r\n			<td>\r\n			<p>100 BPM For 100 Gms.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><span style=\"font-size:13px\">Direction of Movement</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:13px\">Left to Right</span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><span style=\"font-size:13px\">No. of Groove</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:13px\">16 Heads</span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" rowspan=\"2\">\r\n			<p><span style=\"font-size:13px\">Electric Specification**</span></p>\r\n			</td>\r\n			<td colspan=\"2\">\r\n			<p><span style=\"font-size:13px\">Main Motor</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:13px\">5 HP / 415 Volts / 50 Hz. (Stirrer)<br />\r\n			Electrical 2 HP / 415 Volts / 50 Hz. ( 16 Head Funnels)</span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n			<p><span style=\"font-size:13px\">Servo Motor</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:13px\">750 watt</span></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><span style=\"font-size:13px\">Height of Conveyor **</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:13px\">860mm (&plusmn; 50mm)</span></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n', '<p><span style=\"font-size:16px\"><strong>Salient Features</strong></span></p>\r\n\r\n<ul>\r\n	<li>&plusmn; 2% depends upon fill size, Powder Type, RH</li>\r\n	<li>Continuous Rotary System &amp; Bottle Lifter Mechanism Low Noise Level, Low</li>\r\n	<li>Power Consumption All Contact parts can be easy dis-assembled for sterilization</li>\r\n	<li>Continuous motion design gives higher output on higher filling volumes</li>\r\n</ul>\r\n'),
(23, 7, 'Rotary Piston Filling Cum Sealing Machine (MONOBLOCK Type)', 'productimage/pro_id23image1.jpg', '<p><strong>Technical Specification:</strong><br />\r\n&nbsp;</p>\r\n\r\n<div class=\"t2\" id=\"add_t2_1\" style=\"margin: 0px; padding: 0px 17px 0px 0px; max-width: 100%; color: rgb(96, 96, 96); font-family: Arial, Helvetica, sans-serif; font-size: 17px; text-align: justify; overflow-x: auto !important;\">\r\n<table border=\"0\" style=\"border-collapse:collapse\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/RFSM-4/4</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/RFSM-6/6</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/RFSM-8/8</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/RFSM12</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/RFSM16</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Output/Hour*</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1500 to 6000</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2500 to 7500</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4000 to 10000</td>\r\n			<td style=\"text-align:left; vertical-align:top\">6500 to 12000</td>\r\n			<td style=\"text-align:left; vertical-align:top\">7000 to 14500 Bottels</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Number of head/Syringe/Cap</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4</td>\r\n			<td style=\"text-align:left; vertical-align:top\">6</td>\r\n			<td style=\"text-align:left; vertical-align:top\">8</td>\r\n			<td style=\"text-align:left; vertical-align:top\">12</td>\r\n			<td style=\"text-align:left; vertical-align:top\">16</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Fill Size***</td>\r\n			<td style=\"text-align:left; vertical-align:top\">30ml to 200ml</td>\r\n			<td style=\"text-align:left; vertical-align:top\">30ml to 200ml</td>\r\n			<td style=\"text-align:left; vertical-align:top\">30ml to 200ml</td>\r\n			<td style=\"text-align:left; vertical-align:top\">30ml to 200ml</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Left to Right</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Electrical Specification**</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Main Machine</td>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\">3 HP / 415 Volts / 50 Hz.</td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\">5 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Oriental Bowl</td>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\">0.25 HP / 415 Volts / 50 Hz.</td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\">0.5 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Conveyor</td>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\">0.5 HP / 415 Volts / 50 Hz.</td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\">0.75 HP / 415 Volts / 50 Hz.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong><span style=\"font-size:16px\">Salient Features</span></strong></p>\r\n\r\n<ul>\r\n	<li>&#39;GMP&#39; Model based on advanced technology</li>\r\n	<li>Single Operator for Two Operations</li>\r\n	<li>Less Floor Area--as both the sections driven by one motor</li>\r\n	<li>No Contamination</li>\r\n	<li>- as immediate sealing of filled bottles</li>\r\n</ul>\r\n'),
(24, 7, 'Eye-Ear Drop (Trio Block)', 'productimage/pro_id24image1.jpg', '<p><strong>Technical Specification:</strong><br />\r\n&nbsp;</p>\r\n\r\n<div class=\"t2\" id=\"add_t2_1\" style=\"margin: 0px; padding: 0px 17px 0px 0px; max-width: 100%; color: rgb(96, 96, 96); font-family: Arial, Helvetica, sans-serif; font-size: 17px; text-align: justify; overflow-x: auto !important;\">\r\n<table border=\"0\" style=\"border-collapse:collapse\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/EDTB-50</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong><span style=\"color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px\">VPM/EDTB</span>-100</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Output/Hour*</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1800 &ndash; 2400 bottles (Up to 10 ml.)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4800 &ndash; 6000 (Up to 10 ml.)</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Number of Filling Head (Filling)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1 Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2 Head</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Number of Filling Head (Inner Plut)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1 Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2 Head</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Number of Filling Head (Screw Capping)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">1 Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2 Head</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Filling Range</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2.ml. To 50 ml.</td>\r\n			<td style=\"text-align:left; vertical-align:top\">2.ml. To 50 ml.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Elecrical Specification (Filling)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Main Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">10 GK Stepper Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">10 Kg Stepper Motor &ndash; 2 Nos</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Conveyor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">90 Watt Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">90 Watt Motor</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Elecrical Specification (Inner Plug)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Vibrotor &ndash; 300 Watt Magneic Coil</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Virbrator &ndash; 300 Watt Magntic Coil</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Elecrical Specification (Screw Capping)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">90 Watt For Head</td>\r\n			<td style=\"text-align:left; vertical-align:top\">90 Watt For Head &ndash; 2 Nos.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Vibrator</td>\r\n			<td style=\"text-align:left; vertical-align:top\">300 Watt Magnetic Coil</td>\r\n			<td style=\"text-align:left; vertical-align:top\">300 Watt Magnetic Coil</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Elecrical Specification (Star Wheel Assly.)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">90 Watt Motor</td>\r\n			<td style=\"text-align:left; vertical-align:top\">4 N/m Servo Motor</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">No Of Grooves</td>\r\n			<td style=\"text-align:left; vertical-align:top\">12 Nos.</td>\r\n			<td style=\"text-align:left; vertical-align:top\">20 Nos.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n', '<p><strong>Salient Features:</strong><br />\r\n&nbsp;</p>\r\n\r\n<ul>\r\n	<li>A very compact &amp; versatile equipment for 3 in one operation</li>\r\n	<li>Unique for small volumes filling for Eye/Ear/Nasal drops</li>\r\n	<li>S &amp; efficient Filling-Inner Plugging &amp;Screw Capping operations in one star wheel.</li>\r\n</ul>\r\n'),
(25, 7, 'Rinsing Filling & Capping Machine (For Mineral Water & Juice Filling)', 'productimage/pro_id25image1.jpg', '<table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" style=\"background-color:rgb(239, 239, 239); color:rgb(58, 58, 58); font-family:calibri; font-size:12px; width:90%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Technical Specifications</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" style=\"background-color:rgb(239, 239, 239); color:rgb(58, 58, 58); font-family:calibri; font-size:12px; width:90%\">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong><span style=\"font-size:13px\">Model</span></strong></td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/RFCM-60</span></strong></td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/RFCM-100</span></strong></td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/RFCM-150</span></strong></td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/RFCM-200</span></strong></td>\r\n			<td><strong><span style=\"font-size:13px\">VPM/RFCM-300</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">No. of Heads</span></td>\r\n			<td><span style=\"font-size:13px\">16-12-6</span></td>\r\n			<td><span style=\"font-size:13px\">18-18-6</span></td>\r\n			<td><span style=\"font-size:13px\">24-24-8</span></td>\r\n			<td><span style=\"font-size:13px\">32-32-10</span></td>\r\n			<td><span style=\"font-size:13px\">40-40-12</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Capacity @ 1000 ml.</span></td>\r\n			<td><span style=\"font-size:13px\">2700 BPH</span></td>\r\n			<td><span style=\"font-size:13px\">4100 BPH</span></td>\r\n			<td><span style=\"font-size:13px\">5400 BPH</span></td>\r\n			<td><span style=\"font-size:13px\">7200 BPH</span></td>\r\n			<td><span style=\"font-size:13px\">9000 BPH</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Rinsing Water<br />\r\n			Consumption<br />\r\n			@ 0.2 ~ 0.25 Mpa</span></td>\r\n			<td><span style=\"font-size:13px\">800 Ltr / hr</span></td>\r\n			<td><span style=\"font-size:13px\">1600 Ltr / hr</span></td>\r\n			<td><span style=\"font-size:13px\">2500 Ltr / hr</span></td>\r\n			<td><span style=\"font-size:13px\">3500 Ltr / hr</span></td>\r\n			<td><span style=\"font-size:13px\">4000 Ltr / hr</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Compressed Air<br />\r\n			Consumption<br />\r\n			@ 6 to 8 Bar</span></td>\r\n			<td><span style=\"font-size:13px\">6 to 8 Bar</span></td>\r\n			<td><span style=\"font-size:13px\">6 to 8 Bar</span></td>\r\n			<td><span style=\"font-size:13px\">6 to 8 Bar</span></td>\r\n			<td><span style=\"font-size:13px\">6 to 8 Bar</span></td>\r\n			<td><span style=\"font-size:13px\">6 to 8 Bar</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Electic Power</span></td>\r\n			<td><span style=\"font-size:13px\">4.23 KW</span></td>\r\n			<td><span style=\"font-size:13px\">5.03 KW</span></td>\r\n			<td><span style=\"font-size:13px\">6.57 KW</span></td>\r\n			<td><span style=\"font-size:13px\">8.63 KW</span></td>\r\n			<td><span style=\"font-size:13px\">9.63 KW</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Weight</span></td>\r\n			<td><span style=\"font-size:13px\">2500 Kgs.</span></td>\r\n			<td><span style=\"font-size:13px\">3500 Kgs.</span></td>\r\n			<td><span style=\"font-size:13px\">5500 Kgs.</span></td>\r\n			<td><span style=\"font-size:13px\">8000 Kgs.</span></td>\r\n			<td><span style=\"font-size:13px\">10000 Kgs.</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:13px\">Bottle Size Range</span></td>\r\n			<td><span style=\"font-size:13px\">200 to 2000 ml.</span></td>\r\n			<td><span style=\"font-size:13px\">200 to 2000 ml.</span></td>\r\n			<td><span style=\"font-size:13px\">200 to 2000 ml.</span></td>\r\n			<td><span style=\"font-size:13px\">200 to 2000 ml.</span></td>\r\n			<td>200 to 2000 ml.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n', '<h2>Sailent Features</h2>\r\n\r\n<ul>\r\n	<li>Air Blow Conveyor on the in feed.</li>\r\n	<li>Slat Belt Conveyor on the out feed with Inspection Table.</li>\r\n	<li>No Bottle - No Rinse - No Fill - No Cap.</li>\r\n	<li>Unique Pick &amp; Place type Capping with adjustable torque mechanism.</li>\r\n	<li>Speed Control by AC Drive.</li>\r\n	<li>Cap Elevator for feeding cap to the chute with automatic operation.</li>\r\n	<li>Cap elevator for feeding cap to the chute with automatic operation.</li>\r\n	<li>Stainless Steel enclosure provided for complete hygienic bottling.</li>\r\n	<li>Easy open nozzles for easy cleaning.</li>\r\n	<li>Can be linked directly to Automatic Blow Molding Machine for online Blow- Rinse-Fill-Seal.</li>\r\n</ul>\r\n');
INSERT INTO `product` (`product_id`, `category_id`, `product_name`, `image1`, `product_description`, `Features`) VALUES
(26, 8, 'Online Bottle Visual Inspection Machine', 'productimage/pro_id26image1.jpg', '<table border=\"0\" style=\"border-collapse:collapse; color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px; text-align:justify\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;<strong>VPM/BVI/2X2</strong>&nbsp;</td>\r\n			<td style=\"text-align:left; vertical-align:top\">&nbsp;<strong>VPM/BVI/2X2&nbsp;â€‹</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Direction of Movement</td>\r\n			<td style=\"text-align:left; vertical-align:top\">left to Right</td>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px\">&nbsp;4300 to 9000 nos</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Output</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Up to 100 Containers / minute</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Up to 150 Container/Minute</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">No of Operator</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Four (2X2, Two Side Seated)</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Six (3X2, Two Side Seated)</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Power Characteristics</td>\r\n			<td colspan=\"2\" style=\"text-align:left; vertical-align:top\">0.5 HP / 220 Volts / 50 Hz.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '<div class=\"ta lnh_mn fnt8_sh bo1 m57_des\" id=\"cat_desc2\" style=\"margin: -14px 0px 35px; padding: 0px; text-align: justify; color: rgb(96, 96, 96); font-size: 17px; line-height: 30px; font-family: Arial, Helvetica, sans-serif;\">\r\n<ul>\r\n	<li>A/C frequency variable drive.</li>\r\n	<li>PVC black &amp; white board as Per GMP norms.</li>\r\n	<li>UHMW self lubrication guide below chain.</li>\r\n	<li>Adjustable height of conveyor belt, to align with other machines of the line.</li>\r\n	<li>Self alignment bearing for easy maintenance.</li>\r\n	<li>Rigid Vibration free construction for trouble free performance.</li>\r\n</ul>\r\n</div>\r\n\r\n<div class=\"cb\" style=\"margin: 0px; padding: 0px; clear: both; color: rgb(96, 96, 96); font-family: Arial, Helvetica, sans-serif; font-size: 17px; text-align: center;\">&nbsp;</div>\r\n'),
(27, 8, 'Packaging Conveyor Belt', 'productimage/pro_id27image1.jpg', '<table border=\"0\" style=\"border-collapse:collapse; color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px; text-align:justify\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>Model</strong></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><strong>VPM/PC</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">Direction of Movement</td>\r\n			<td style=\"text-align:left; vertical-align:top\">Left to Right</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\" style=\"text-align:left; vertical-align:top\">Speed</td>\r\n			<td style=\"text-align:left; vertical-align:top\">7.5 Mtr./Min. upto 12 fee Long</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">12 Mtr./ Min from 13 Feet to 24 Feet Long</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\" style=\"text-align:left; vertical-align:top\">Power Characteristics</td>\r\n			<td style=\"text-align:left; vertical-align:top\">0.25 HP / 220 V / 50 Hz up to 12 Feet Long</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\">0.5 HP / 220 V / 50 Hz up to 13 Feet to 24 Feet Long</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n', '<ul>\r\n	<li>Structure is made of S.S. 3G4, 30 mm sq. pipe, 16 SWG with matt finish.</li>\r\n	<li>A/c frequency variable drive.</li>\r\n	<li>Belt-alignment system for long life &amp; straight running of belt.</li>\r\n	<li>S.S. elegantly matt finishing.</li>\r\n	<li>Adjustable height of conveyor belt to align with other machines of the line.</li>\r\n	<li>Self-alignment bearing for easy maintenance.</li>\r\n	<li>Rigid vibration free construction for trouble free performance.</li>\r\n</ul>\r\n'),
(28, 8, 'Turntable', 'productimage/pro_id28image1.jpg', '<table border=\"0\" style=\"border-collapse:collapse; color:rgb(96, 96, 96); font-family:arial,helvetica,sans-serif; font-size:17px; text-align:justify\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">Model</span></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">VPM/TT -30</span></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">VPM/TT-36</span></td>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">VPM/TT-42</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">Direction</span></td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">Clockwise / Anti clockwise as per requirement</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">RPM of Disk</span></td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\">By VFD</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">Power Characteristics</span></td>\r\n			<td colspan=\"3\" style=\"text-align:left; vertical-align:top\"><span style=\"font-size:13px\">0.5 HP / 415V / 50 Hz.</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&quot;</p>\r\n', '<ul>\r\n	<li>Construction AISI S.S. 304 quality</li>\r\n	<li>Three Step pulleys for Different speed.</li>\r\n	<li>Special Self-aligning bearings ensure smooth and trouble free operation.</li>\r\n	<li>S.S. Elegantly matt finished body.</li>\r\n	<li>Reduction gear ensures jerk free and noiseless operation.</li>\r\n	<li>Acrylic covers and AC Frequency drive operations available.</li>\r\n</ul>\r\n'),
(35, 8, 'SCREW CONVEYOR FOR POWDER', 'productimage/pro_id35image1.jpg', '', ''),
(29, 8, 'CAP ELEVATOR VPM/CE', 'productimage/pro_id29image1.jpg', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Power</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Electrical Specifications</td>\r\n			<td>1 HP / 220 Volts / A.C</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Dimensions</td>\r\n			<td>2220 mm (L) x 730 mm<br />\r\n			(W) x 2420 mm (H)</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '');

-- --------------------------------------------------------

--
-- Table structure for table `qcontact`
--

CREATE TABLE `qcontact` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `email` int(11) NOT NULL,
  `contactno` int(11) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_id` int(13) NOT NULL,
  `service_name` varchar(200) NOT NULL,
  `image1` varchar(200) NOT NULL,
  `service_description` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `service_name`, `image1`, `service_description`) VALUES
(1, 'Hello', 'service/service_id1image1.jpg', '<p>Hello this is service page test need to build service page dynamically so will try to make better then ever so please be helpfull to me and my code so i can build more clkean.Hello this is service page test need to build service page dynamically so will try to make better then ever so please be helpfull to me and my code so i can build more clean.</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n'),
(2, 'Hello2', 'service/service_id2image1.jpg', '<p>HEllo 2 is onther service which we are taking for our refrence and check to is it working or not so dont take any stress and think about it it&#39;s just dummy and simple&nbsp;HEllo 2 is onther service which we are taking for our refrence and check to is it working or not so dont take any stress and think about it it&#39;s just dummy and simple&nbsp;HEllo 2 is onther service which we are taking for our refrence and check to is it working or not so dont take any stress and think about it it&#39;s just dummy and simple&nbsp;HEllo 2 is onther service which we are taking for our refrence and check to is it working or not so dont take any stress and think about it it&#39;s just dummy and simple&nbsp;HEllo 2 is onther service which we are taking for our refrence and check to is it working or not so dont take any stress and think about it it&#39;s just dummy and simple&nbsp;</p>\r\n\r\n<p>&quot;</p>\r\n\r\n<p>&quot;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(11) NOT NULL,
  `image1` varchar(200) NOT NULL,
  `title` text NOT NULL,
  `desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `image1`, `title`, `desc`) VALUES
(1, 'productimage/slider_id1image1.png', '', ''),
(2, 'productimage/slider_id2image1.jpg', '', ''),
(3, 'productimage/slider_id3image1.jpg', '', ''),
(4, 'productimage/slider_id4image1.jpg', '', ''),
(5, 'productimage/slider_id5image1.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(13) NOT NULL,
  `category_id` int(13) NOT NULL,
  `sub_category_name` varchar(200) NOT NULL,
  `status` int(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `category_id`, `sub_category_name`, `status`) VALUES
(1, 1, 'AHD/CVI/TVI/CVBS CAMERA', 0),
(2, 1, 'IP Camera', 0),
(3, 2, 'IP WIFI CAMERA', 0),
(4, 2, 'Fisheye IP Camera', 0),
(5, 2, 'Fisheye AHD/CVI/TVI/CVBS CAMERA', 0),
(6, 3, 'AHD Camera', 0),
(7, 3, 'HDCVI Camera', 0),
(8, 3, 'HDTVI Camera', 0),
(9, 3, 'AHD/CVI/TVI/ANALOGE ALL IN ONE CAMERA', 0),
(10, 4, 'H.264 Basic IP Camera', 0),
(11, 4, 'H.264 Multi-function IP Camera', 0),
(12, 4, 'H.265 Basic IP Camera', 0),
(13, 4, 'H.265 Multi-Function IP Camera', 0),
(14, 4, 'Motorized IP Camera', 0),
(15, 5, 'Analog HD Series PTZ', 0),
(16, 5, 'Analog Series PTZ', 0),
(17, 5, 'Network Smart Series PTZ', 0),
(18, 6, 'CMOS 700TVL', 0),
(19, 6, 'CMOS 1000TVL', 0),
(20, 6, 'CCD 700TVL', 0),
(21, 6, 'CCD WDR 700TVL', 0),
(22, 6, 'CCD 800TVL', 0),
(23, 7, 'HD Coaxial DVR', 0),
(24, 7, 'NVR', 0),
(25, 7, '960H DVR', 0),
(26, 8, 'WIFI SERIES', 0),
(27, 8, 'AHD SERIES', 0),
(28, 8, 'NVR KITS', 0),
(29, 9, 'Video Balun', 0),
(30, 9, 'CCTV Tester', 0),
(31, 9, 'Power Supply', 0),
(32, 9, 'Isolator', 0),
(33, 9, 'Optical', 0),
(34, 9, 'Video Extension', 0),
(35, 9, 'Audio', 0),
(36, 9, 'Camera Bracket', 0),
(37, 9, 'Connectors', 0),
(38, 9, 'Housing', 0),
(39, 9, 'Lens', 0),
(40, 9, 'Cables', 0),
(41, 9, 'POE Switch&Spiliter', 0),
(42, 9, 'Converter', 0),
(43, 9, 'PTZ Keyboard', 0);

-- --------------------------------------------------------

--
-- Table structure for table `thought`
--

CREATE TABLE `thought` (
  `thought_id` int(11) NOT NULL,
  `thought` text NOT NULL,
  `auther_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1:admin,2:employee',
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`uid`, `name`, `username`, `password`, `type`, `status`) VALUES
(1, 'Admin', 'admin', 'admin', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `video_id` int(11) NOT NULL,
  `vname` text NOT NULL,
  `category` varchar(20) NOT NULL,
  `path` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`video_id`, `vname`, `category`, `path`) VALUES
(2, 'Unboxing Mapesen 4CH Wireless HD 720P 1 0MP WIFI NVR KIT', 'Product', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/z2SaHcDCmos\" frameborder=\"0\" allowfullscreen></iframe>'),
(3, 'MAPESEN 2 0MP 18X Starlight PTZ Network Camera', 'Product', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/fLmV8licA2M\" frameborder=\"0\" allowfullscreen></iframe>'),
(4, 'MAPESEN Starlight L2QSC2 Bullet Camera Night Vision', 'Product', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/Oq0hhcL4aeo\" frameborder=\"0\" allowfullscreen></iframe>'),
(6, 'Mapesen Starlight Video', 'Product', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/Jhqs_iDgYH4\" frameborder=\"0\" allowfullscreen></iframe>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus`
--
ALTER TABLE `aboutus`
  ADD PRIMARY KEY (`abt_id`);

--
-- Indexes for table `brocher`
--
ALTER TABLE `brocher`
  ADD PRIMARY KEY (`brocher_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `gallary`
--
ALTER TABLE `gallary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`inquiry_id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`Model_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `qcontact`
--
ALTER TABLE `qcontact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `thought`
--
ALTER TABLE `thought`
  ADD PRIMARY KEY (`thought_id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`video_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus`
--
ALTER TABLE `aboutus`
  MODIFY `abt_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brocher`
--
ALTER TABLE `brocher`
  MODIFY `brocher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gallary`
--
ALTER TABLE `gallary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `inquiry_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
  MODIFY `Model_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `offer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `qcontact`
--
ALTER TABLE `qcontact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `service_id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `thought`
--
ALTER TABLE `thought`
  MODIFY `thought_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
