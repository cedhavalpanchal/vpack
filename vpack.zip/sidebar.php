
						<ul class="categories_list second_font w_break">
							<?php include('config.php');

				            $sql="select * from category";
				            $res=mysqli_query($conn,$sql);
				            
				            while($fatch=mysqli_fetch_array($res))
				            { 
				            	?>

                    		<?php $cn=$fatch['category_id']; 
$fpr="select * from product where category_id='".$cn."'";
$rpro=mysqli_query($conn,$fpr);
 $rproCount = 0;
    $rprototal = 0;
        
    if($rpro){
        $rproCount = mysqli_num_rows($rpro);
        $rprototal = $rproCount;
    }
    if($rproCount > 0){
        //$rpro = mysqli_query($conn,$rpro);
    }
                    		?>
							<li class="relative">
								<a href="category.php?scid=<?php echo $cn; ?>&&nam=<?php echo $fatch['category_name']; ?>" class="fs_large_0 d_inline_b"><?php echo $fatch['category_name']; ?> </a>
								<?php if($rproCount > 0){  ?>
								<button class="open_sub_categories fs_medium"></button>
										<!--third level-->
										<ul class="d_none fs_small categories_third_level_list">
											<?php while($fatch1=mysqli_fetch_array($rpro))
				            {  ?>
											<li><a href="product.php?pid=<?php echo $fatch1['product_id']; ?>" class="tr_delay sc_hover bg_grey_light_2_hover"><?php echo $fatch1['product_name']; ?></a></li> <?php } ?>
											<!-- <li><a href="#" class="sc_hover bg_grey_light_2_hover">Queen Beds</a></li> -->
										</ul>
										<?php  } ?>
							</li>
							<?php } ?>
						</ul>
						
					</section>
				</aside>