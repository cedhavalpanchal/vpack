<?php include('header.php'); ?>

		<!--breadcrumbs-->
		<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
			<div class="container">
				<a href="index.php" class="sc_hover">Home</a> / <span class="color_light">Products</span>
			</div>
		</div>
		<!--main content-->
		<div class="page_section_offset">
			<div class="container">
				<div class="row">
					<aside class="col-lg-3 col-md-3 col-sm-3">
						<section class="m_bottom_30">
							<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">Categories</h5>
							<hr class="divider_bg m_bottom_23">

							<?php include('sidebar.php'); ?>
						</section>
					</aside>

					<?php $cname=$_REQUEST['nam']; ?>
					<main class="col-lg-9 col-md-9 col-sm-9 m_bottom_30 m_xs_bottom_10">
						<h5 class="fw_light second_font color_dark tt_uppercase m_bottom_15"><?php echo $cname; ?></h5>
						<hr class="divider_bg m_bottom_50">
						
						<div class="row">
							<!--Product Start -->
							<?php include('config.php');

							$scid=$_REQUEST['scid'];
				            $sql= "select * from product where category_id= $scid";
				            if($scid!=4 && $scid!=3 && $scid!=5){
				            	$sql .= " order by product_id DESC"; 
				            }
				            
				           	$res= mysqli_query($conn,$sql);
				        	$rowCount = 0;
				        	$total = 0;

			        		if($res){
				        		$rowCount = mysqli_num_rows($res);
				        		$total = $rowCount;
				        	}
				        	if($rowCount > 0){
				            	$res = mysqli_query($conn,$sql);
				        	}
			       			if($rowCount < 1){
		            			//No records in the table.
				            	echo "<strong> No Records Found !!! </strong> ";
				        	}else{
							while($fetch = mysqli_fetch_array($res))
		                    {
				        	?>
							<div class="col-lg-4 col-md-4 col-sm-3 m_xs_bottom_30 m_bottom_40 animated hidden" data-animation="fadeInDown" data-animation-delay="200">
								<!--product-->
								<figure class="product_item type_2 c_image_container relative frame_container t_sm_align_c r_image_container qv_container">
									<!--image & buttons & label-->
									<div class="relative">
										<div class="pro_img">
											<img src="Back-vpack/<?php echo $fetch['image1']; ?>" alt="<?php echo $fetch['product_name']; ?>" class="c_image_1 tr_all">	
										</div>
									</div>
									<figcaption class="bg_white relative p_bottom_0">
										<div class="row">
											<div class="col-lg-12 col-md-12 m_bottom_9">
												<a class="second_font sc_hover d_xs_block big" href="product.php?pid=<?php echo $fetch['product_id']; ?>"><?php echo $fetch['product_name']; ?></a>	
											</div>
										</div>
									</figcaption>
								</figure>
								<div class="button">
									<a href="product.php?pid=<?php echo $fetch['product_id']; ?>">VIEW DETAILS</a>
								</div>
							</div>
							<?php } } ?>
							<!-- Products End -->
							</div>	
					</main>
				</div>
			</div>
		</div>
			
<?php include('footer.php'); ?>