<?php include('header.php');

if(isset($_REQUEST['pid'])){
	$pid=$_REQUEST['pid'];
	$sql1= "select * from product JOIN category  ON product.category_id= category.category_id  where product.product_id=$pid";
    $sql1 .= " order by product_id DESC";
    $res1= mysqli_query($conn,$sql1);
    $rowCount = 0;
    $total = 0;
        
    if($res1){
        $rowCount = mysqli_num_rows($res1);
        $total = $rowCount;
    }
    if($rowCount > 0){
        $res1 = mysqli_query($conn,$sql1);
    }
    if($rowCount < 1){
        //No records in the table.
        echo "<strong> No Records Found !!! </strong> ";
    }
    else{
        $fetch1 = mysqli_fetch_array($res1);
	?>

	<!--breadcrumbs-->
	<div class="breadcrumbs bg_grey_light_2 fs_medium fw_light">
		<div class="container">
			<a href="index.php" class="sc_hover">Home</a> / <span class="color_light"><?php echo $fetch1['product_name']; ?></span>
		</div>
	</div>
	<!--main content-->
	<div class="page_section_offset">
		<div class="container">
			<div class="row">
				<aside class="col-lg-3 col-md-3 col-sm-3">
					<!--categories widget-->
					<section class="m_bottom_30">
						<h5 class="color_dark tt_uppercase second_font fw_light m_bottom_13">Categories</h5>
						<hr class="divider_bg m_bottom_23">

						<?php include('sidebar.php'); ?>
					</section>
				</aside>
				<section class="col-lg-9 col-md-9 col-sm-9">
					<main class="m_bottom_40 m_xs_bottom_30">
						<div class="product_preview f_left f_xs_none wrapper m_xs_bottom_15">
							<div class="d_block relative r_image_container">
								<img src="Back-vpack/<?php echo $fetch1['image1']; ?>" alt="<?php echo $fetch1['product_name']; ?>" />
								<!--id="zoom" data-zoom-image="Back-vpack/<?php echo $fetch1['image1']; ?>" -->
							</div>
						</div>
						<div class="product_description f_left f_xs_none">
							<div class="wrapper">
								<h3 class="second_font m_bottom_10 f_left product_title"><a href="#" class="sc_hover"><?php echo $fetch1['product_name']; ?></a></h3>
							</div>
							<hr class="divider_light m_bottom_15">
							<p class="fw_light m_bottom_14 color_grey"><?php echo $fetch1['product_description']; ?></p>
						</div>
					</main>
					<?php if ($fetch1['Features']!="") {
 					?>
					<!--tabs-->
					<div class="tabs styled_tabs m_bottom_18">
						<nav class="second_font">
							<ul class="hr_list">
								<li class="m_right_3"><a href="#tab1" class="color_light border_light_3 d_block">Features</a></li>
							</ul>
						</nav>
						<hr class="d_xs_none">
						<div id="tab1" class="fw_light tab_content">
							<p class="m_bottom_13"><?php echo $fetch1['Features']; ?></p>
						</div>
					</div>
					<?php } ?>
				</section>
			</div>
		</div>
	</div>

<?php  } }
else{
    echo" <script>alert('Please Select The Product First....');</script>";
	header("location:index.php");
}
include('footer.php');?>