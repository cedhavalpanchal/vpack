<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php");



if(isset($_REQUEST['submit']))
{
	$city_id=$_REQUEST['city_name'];
	$property_id=$_REQUEST['property_id'];
	$temp_id=$_REQUEST['temp_id'];
	$category_id=$_REQUEST['cat'];
	$customer_master_name = $_REQUEST['customer_name'];
	$customer_mobile = $_REQUEST['customer_mobile'];
	$property_address = $_REQUEST['property_address'];
	$area_id = $_REQUEST['area_id'];
	$cat= $_REQUEST['cat'];
	$property_name= $_REQUEST['property_name'];
	$property_type= $_REQUEST['property_type'];
	$sq_feet= $_REQUEST['sq_feet'];
	$rooms= $_REQUEST['rooms'];
	$price = $_REQUEST['price'];
	$details = $_REQUEST['details'];
	$pf=$_REQUEST['check'];
	$s='1';
	$check_popular=$_REQUEST['check_popular'];
	$check_feature=$_REQUEST['check_feature'];
	echo "<script>alert('$check_popular')</script>";
	echo "<script>alert('$check_feature')</script>";
	
		if($_FILES['file1']['name'])
		 {
	   
			$fname=$_FILES['file1']['name'];
			$tmp=$_FILES['file1']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img1".$ext;
	
			$path1="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path1))	
			{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
							
			if($_FILES['file2']['name'])
		 {
	   
			$fname=$_FILES['file2']['name'];
			$tmp=$_FILES['file2']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img2".$ext;
	
 $path2="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path2))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file3']['name'])
		 {
	   
			$fname=$_FILES['file3']['name'];
			$tmp=$_FILES['file3']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img3".$ext;
	
 $path3="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path3))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file4']['name'])
		 {
	   
			$fname=$_FILES['file4']['name'];
			$tmp=$_FILES['file4']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img4".$ext;
	
 $path4="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path4))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file5']['name'])
		 {
	   
			$fname=$_FILES['file5']['name'];
			$tmp=$_FILES['file5']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img5".$ext;
	
 $path5="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path5))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file6']['name'])
		 {
	   
			$fname=$_FILES['file6']['name'];
			$tmp=$_FILES['file6']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img6".$ext;
	
 $path6="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path6))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file7']['name'])
		 {
	   
			$fname=$_FILES['file7']['name'];
			$tmp=$_FILES['file7']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img7".$ext;
	
 $path7="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path7))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file8']['name'])
		 {
	   
			$fname=$_FILES['file8']['name'];
			$tmp=$_FILES['file8']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img8".$ext;
	
 $path8="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path8))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file9']['name'])
		 {
	   
			$fname=$_FILES['file9']['name'];
			$tmp=$_FILES['file9']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img9".$ext;
	
 $path9="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path9))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($_FILES['file10']['name'])
		 {
	   
			$fname=$_FILES['file10']['name'];
			$tmp=$_FILES['file10']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img10".$ext;
	
 $path10="gallery/".$nfname;
							
			if(move_uploaded_file($tmp,$path10))	
		{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							}	
							}
	
	
	if($check_popular==1)
	{
	   
	
			 $update = "update property set customer_name= '".$customer_master_name."',temp_id='".$temp_id."',
			customer_mobile= '".$customer_mobile."',property_address= '".$property_address."',	area_id= '".$area_id."',	category_name= '".$cat."',	property_name= '".$property_name."',	property_type= '".$property_type."',sq_feet= '".$sq_feet."',rooms= '".$rooms."',price = '".$price."',property_description = '".$details."',status='".$s."',	popular='".$check_popular."',feature='".$check_feature."'";
					if($_FILES['file1']['name']!="") 
					$update .= ",img1= '".$path1."'";
					
					 if($_FILES['file2']['name']!="") 
				$update .= ",img2= '".$path2."'";
					
					 if($_FILES['file3']['name']!="") 
				$update .= ",img3= '".$path3."'";
					
					 if($_FILES['file4']['name']!="") 
				$update .= ",img4= '".$path4."'";
					
					 if($_FILES['file5']['name']!="") 
				$update .= ",img5= '".$path5."'";
					
					 if($_FILES['file6']['name']!="") 
				$update .= ",img6= '".$path6."'";
					
					 if($_FILES['file7']['name']!="") 
				$update .= ",img7= '".$path7."'";
					
					 if($_FILES['file8']['name']!="") 
				$update .= ",img8= '".$path8."'";	
				
					 if($_FILES['file9']['name']!="") 
				$update .= ",img9= '".$path9."'";
					
					 if($_FILES['file10']['name']!="") 
				$update .= ",img10= '".$path10."'";	
				
			$update .=" WHERE property_id =".$property_id."";
			
			
			

			
		if (mysqli_query($conn,$update) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Details succesfully Update....');</script>";
			header("location:property_list.php?update=1");
		}
		else
		{
			echo "<script> alert('Invalid Data')</script>";
		}
	}
	else if( $check_feature==1)
	{
		$update = "update property set customer_name= '".$customer_master_name."',temp_id='".$temp_id."',
			customer_mobile= '".$customer_mobile."',property_address= '".$property_address."',	area_id= '".$area_id."',	category_name= '".$cat."',	property_name= '".$property_name."',	property_type= '".$property_type."',sq_feet= '".$sq_feet."',rooms= '".$rooms."',price = '".$price."',property_description = '".$details."',status='".$s."',	popular='".$check_popular."',feature='".$check_feature."'";
					if($_FILES['file1']['name']!="") 
					$update .= ",img1= '".$path1."'";
					
					 if($_FILES['file2']['name']!="") 
				$update .= ",img2= '".$path2."'";
					
					 if($_FILES['file3']['name']!="") 
				$update .= ",img3= '".$path3."'";
					
					 if($_FILES['file4']['name']!="") 
				$update .= ",img4= '".$path4."'";
					
					 if($_FILES['file5']['name']!="") 
				$update .= ",img5= '".$path5."'";
					
					 if($_FILES['file6']['name']!="") 
				$update .= ",img6= '".$path6."'";
					
					 if($_FILES['file7']['name']!="") 
				$update .= ",img7= '".$path7."'";
					
					 if($_FILES['file8']['name']!="") 
				$update .= ",img8= '".$path8."'";	
				
					 if($_FILES['file9']['name']!="") 
				$update .= ",img9= '".$path9."'";
					
					 if($_FILES['file10']['name']!="") 
				$update .= ",img10= '".$path10."'";	
				
			$update .=" WHERE property_id =".$property_id."";
			
			
			

			
		if (mysqli_query($conn,$update) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Details succesfully Update....');</script>";
			 header("location:property_list.php?update=1");
		}
		else
		{
			echo "<script> alert('Invalid Data')</script>";
		}
	}
	else
	{
		$update = "update property set customer_name= '".$customer_master_name."',temp_id='".$temp_id."',
			customer_mobile= '".$customer_mobile."',property_address= '".$property_address."',	area_id= '".$area_id."',	category_name= '".$cat."',	property_name= '".$property_name."',	property_type= '".$property_type."',sq_feet= '".$sq_feet."',rooms= '".$rooms."',price = '".$price."',property_description = '".$details."',status='".$s."',	popular='".$check_popular."',feature='".$check_feature."'";
					if($_FILES['file1']['name']!="") 
					$update .= ",img1= '".$path1."'";
					
					 if($_FILES['file2']['name']!="") 
				$update .= ",img2= '".$path2."'";
					
					 if($_FILES['file3']['name']!="") 
				$update .= ",img3= '".$path3."'";
					
					 if($_FILES['file4']['name']!="") 
				$update .= ",img4= '".$path4."'";
					
					 if($_FILES['file5']['name']!="") 
				$update .= ",img5= '".$path5."'";
					
					 if($_FILES['file6']['name']!="") 
				$update .= ",img6= '".$path6."'";
					
					 if($_FILES['file7']['name']!="") 
				$update .= ",img7= '".$path7."'";
					
					 if($_FILES['file8']['name']!="") 
				$update .= ",img8= '".$path8."'";	
				
					 if($_FILES['file9']['name']!="") 
				$update .= ",img9= '".$path9."'";
					
					 if($_FILES['file10']['name']!="") 
				$update .= ",img10= '".$path10."'";	
				
			$update .=" WHERE property_id =".$property_id."";
			
			
			

			
		if (mysqli_query($conn,$update) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Details succesfully Update....');</script>";
			header("location:property_list.php?update=1");
		}
		else
		{
			echo "<script> alert('Invalid Data')</script>";
		}
	}

}


if(isset($_REQUEST['delete1']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name1'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		$img1=$fetch['img1'];
		$img2=$fetch['img2'];
		if($name == $img1)
		{
			
			$delete="update property set img1='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 1 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete2']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name2'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		$img1=$fetch['img1'];
		$img2=$fetch['img2'];
		if($name == $img2)
		{
			
			$delete="update property set img2='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 2 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete3']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name3'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img3=$fetch['img3'];
		if($name == $img3)
		{
			
			$delete="update property set img3='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 3 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}

if(isset($_REQUEST['delete4']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name4'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img4=$fetch['img4'];
		if($name == $img4)
		{
			
			$delete="update property set img4='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 4 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete5']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name5'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img5=$fetch['img5'];
		if($name == $img5)
		{
			
			$delete="update property set img5='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 5 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete6']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name6'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img6=$fetch['img6'];
		if($name == $img6)
		{
			
			$delete="update property set img6='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 6 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete7']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name7'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img7=$fetch['img7'];
		if($name == $img7)
		{
			
			$delete="update property set img7='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 7 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete8']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name8'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img8=$fetch['img8'];
		if($name == $img8)
		{
			
			$delete="update property set img8='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 8 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete9']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name9'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img9=$fetch['img9'];
		if($name == $img9)
		{
			
			$delete="update property set img9='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				
				echo" <script>alert('Image 9 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}
if(isset($_REQUEST['delete10']))
{
	$id=$_REQUEST['property_id'];
	$name=$_REQUEST['name10'];
	unlink($name);
	$sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
	$qry = mysqli_query($conn,$sel);
	
	while($fetch = mysqli_fetch_array($qry))
	{
		
		
		$img10=$fetch['img10'];
		if($name == $img10)
		{
			
			$delete="update property set img10='' where property_id='$id'";
			if (mysqli_query($conn,$delete) or die(mysqli_error($conn)))
			{
				echo" <script>alert('Image 10 Delete Succesfully  ....');</script>";
				//header("location:property_list.php?update=1");
			}
			else
			{
				echo "<script> alert('Invalid Data')</script>";
			}
		}
		else 
		{
			echo "<script> alert('Image Not Match...')</script>";
		}
	}
	//unlink("uploads/".$row['file']);
}

?>

<title>Edit Record Information</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>

 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>
		

<!------------------------------------------------------------->
<script src="http://cdn.ckeditor.com/4.4.7/full/ckeditor.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />


<!------------------------------------------------------------->
<?php
if(isset($_REQUEST['edit_id']))
{
 $id = $_GET['edit_id'];
 $sel = "SELECT * FROM  `property` WHERE   `property`.`property_id`=$id";
 $qry = mysqli_query($conn,$sel);
 $fetch = mysqli_fetch_array($qry);
}
?>
<div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu multipletabmenu">
                    <li class="current"><a href="">Update Property Detail</a></li>
                    <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='property_list.php'" />
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>EDIT Property Details</span></h2>
                    </div><!--contenttitle-->

					
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)">
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
                                                      
							<tr>
                               <td></td>
                               <td><input type="hidden" id="property_id" name="property_id" class="mediuminput" value="<?php echo $fetch['property_id'] ?>" readonly="customer_detail_id" /> 
                               </td>
                            </tr>
							
                             <tr>
                               <td>Property id</td>
                               <td><input type="text" id="temp_id" name="temp_id" class="mediuminput" value="<?php echo $fetch['temp_id']; ?>" readonly="customer_detail_id" /> 
                               </td>
                            </tr>
							
							 
						<tr>
			   <td>Customer Name<font color="#FF0000">*</font></td>
							<td>  
                         <input type="text"  name="customer_name" placeholder="Customer Name" value="<?php echo $fetch['customer_name']; ?>" class="mediuminput"  title="Please Enter Alphanumeric Character..." required/> 
                         </td>
						</tr>
						<tr>
			   <td>Customer Mobile<font color="#FF0000">*</font></td>
							<td>  
                         <input type="text"  name="customer_mobile" placeholder="Customer Mobile NO." value="<?php echo $fetch['customer_mobile']; ?>" class="mediuminput"  title="Please Enter Number..." required/> 
                         </td>
						</tr>
						<tr>
			   <td>Property Address<font color="#FF0000">*</font></td>
							<td>  
                         <input type="text"  name="property_address" placeholder="Property Address" value="<?php echo $fetch['property_address']; ?>" class="mediuminput"  title="Please Enter Alphanumeric Character..." required/> 
                         </td>
						</tr>
						<td> 
                          Area<font color="#FF0000">*</font>
						
							</td>
							<td>
							   <?php

								 $query = 'SELECT * FROM area';
									$result = mysqli_query($conn,$query) or die(mysqli_error($conn));
									echo "<select name='area_id' id='pro_id' required/>";
									echo "<option value =''>Select City</option>";
									while ($row = mysqli_fetch_array($result)){
									  $city_name = $row['area_name']; 
									  $city_id = $row['area_id'];
									  ?> <option value='<?php echo $city_id;?>' <?php if($row['area_id']==$fetch['area_id']){?> selected="selected" <?php }?>><?php echo $city_name ; ?></option>
									<?php }

									echo "</select>";
								?>
							</td>
                            </tr>
						<tr><td> 
                          Category Name<font color="#FF0000">*</font>
						
							</td>
							<td>
                           
							<input type="radio" name="cat" value="buy" <?php if($fetch['category_name']=="buy"){?>checked="checked"<?php }?>/> Buy &nbsp;&nbsp;
                            	<input type="radio" name="cat" value="rent" <?php if($fetch['category_name']=="rent"){?>checked="checked"<?php }?>/> Rent&nbsp;&nbsp;
                           </td>
						</tr>
						
							<tr>
								<td>Property Name<font color="#FF0000">*</font></td>
								<td>
									<input type="text"  name="property_name" value="<?php echo $fetch['property_name']; ?>" size="39" maxlength="39" placeholder="Property Name" class="mediuminput"  title="Property Name" required/> 
								</td>
							</tr>
						
						
						<tr>
						<td> 
                          Property Type<font color="#FF0000">*</font>
						
							</td>
							<td>
								<select name="property_type">
								 
								   <option value="" <?php if($fetch['property_type']==" "){?>selected="selected"<?php }?>  >Select Property Type</option>
									<option value="Apartment" <?php if($fetch['property_type']=="Apartment"){?>selected="selected"<?php }?> >Apartment</option>
									<option value="Banglows" <?php if($fetch['property_type']=="Banglows"){?>selected="selected"<?php }?> >Banglows</option>
									<option value="Duplex" <?php if($fetch['property_type']=="Duplex"){?>selected="selected"<?php }?>  >Duplex</option>
									<option value="Tenement" <?php if($fetch['property_type']=="Tenement"){?>selected="selected"<?php }?>>Tenement</option>
									<option value="Plot" <?php if($fetch['property_type']=="Plot"){?>selected="selected"<?php }?>>Plot</option>
									<option value="Villa" <?php if($fetch['property_type']=="Villa"){?>selected="selected"<?php }?>>Villa</option>
									<option value="Penthouse" <?php if($fetch['property_type']=="Penthouse"){?>selected="selected"<?php }?>>Penthouse</option>
									<option value="Ro house" <?php if($fetch['property_type']=="Ro house"){?>selected="selected"<?php }?>>Ro House</option>
								  
									<option value="Shop" <?php if($fetch['property_type']=="Shop"){?>selected="selected"<?php }?>>Shop</option>
										<option value="Office" <?php if($fetch['property_type']=="Office"){?>selected="selected"<?php }?>>Office</option>
										<option value="Showroom" <?php if($fetch['property_type']=="Showroom"){?>selected="selected"<?php }?>>Showroom</option>
								 
								</select>
							
                           </td>
						</tr>
						<td> 
                          Sq.feet<font color="#FF0000">*</font>
						
							</td>
							<td>
							 <input type="text"  name="sq_feet" placeholder="Sq. Feet" class="mediuminput" value="<?php echo $fetch['sq_feet'] ?>" pattern="[0-9]+" title="Enter only Number.." required/> 
                           </td>
						</tr>
						<tr>
						<td> 
                          Rooms<font color="#FF0000">*</font>
						
							</td>
							<td>
								<select name="rooms">
								   <option value="" <?php if($fetch['rooms']==" "){?>selected="selected"<?php }?>  >Select BHK</option>
									<option value="1BHK" <?php if($fetch['rooms']=="1BHK"){?>selected="selected"<?php }?>  >1 BHK</option>
									<option value="2BHK" <?php if($fetch['rooms']=="2BHK"){?>selected="selected"<?php }?> >2 BHK</option>
									<option value="3BHK" <?php if($fetch['rooms']=="3BHK"){?>selected="selected"<?php }?> >3 BHK</option>
									<option value="4BHK" <?php if($fetch['rooms']=="4BHK"){?>selected="selected"<?php }?> >4 BHK</option>
									<option value="5BHK" <?php if($fetch['rooms']=="5BHK"){?>selected="selected"<?php }?> >5 BHK</option>
									<option value="6BHK" <?php if($fetch['rooms']=="6BHK"){?>selected="selected"<?php }?> >6 BHK</option>
									<option value="7BHK" <?php if($fetch['rooms']=="7BHK"){?>selected="selected"<?php }?> >7 BHK</option>
									<option value="8BHK" <?php if($fetch['rooms']=="8BHK"){?>selected="selected"<?php }?> >8 BHK</option>
								</select>
							
                           </td>
						</tr>
							  
                              <tr>
                               <td> Price</td>
                               <td><input type="text" id="fname" name="price" class="mediuminput" value="<?php echo $fetch['price'] ?>" /> 
                               </td>
                            </tr>
                           
							<tr>
                               <td> Property Description</td>
                               <td>
							     <textarea class="ckeditor" name="details"  placeholder="Enter Content" cols="80" rows="10"><?php echo $fetch['property_description'] ?></textarea>  
							   
                               </td>
                            </tr>
							<tr>
							<td>Popular/Feature</td>
							<td>
								<input type="checkbox" name="check_popular" value="1" <?php if($fetch['popular']=="1"){?>checked="checked"<?php }?>/> Popular &nbsp;&nbsp;
								<input type="checkbox" name="check_feature" value="1" <?php if($fetch['feature']=="1"){?>checked="checked"<?php }?>/> Feature&nbsp;&nbsp;
								
								
								<!--<input type="radio" name="check" value="popular" <?php //if($fetch['popular_feature']=="popular"){?>checked="checked"<?php //}?>/> Popular &nbsp;&nbsp;
								<input type="radio" name="check" value="feature" <?php //if($fetch['popular_feature']=="feature"){?>checked="checked"<?php //}?>/> Feature&nbsp;&nbsp;-->
							</td>
						</tr>
                            
				<script>
					
				
				</script>
							
							
		<tr> 
			<td>Image-1</td>
			<td> 
				<img src="<?php echo $fetch['img1'];?>" alt="<?php echo $fetch['img1']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file1" id="file1" /> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name1" value="<?php echo $fetch['img1'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete1" value="DELETE"/> 	
			</td>
		</tr>
		
		<tr> 
			<td>Image-2</td>
			<td>
				<img src="<?php echo $fetch['img2']; ?>" alt="<?php echo $fetch['img2']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file2" id="file2" />  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name2" value="<?php echo $fetch['img2'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete2" value="DELETE"/> 
			</td>
		</tr>
		
		<tr> 
			<td>Image-3</td>
			<td> 
				<img src="<?php echo $fetch['img3']; ?>" alt="<?php echo $fetch['img3']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file3" id="file" />  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name3" value="<?php echo $fetch['img3'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete3" value="DELETE"/>
			</td>
		</tr>
		
		<tr> 
			<td>Image-4</td>
			<td> 
				<img src="<?php echo $fetch['img4']; ?>" alt="<?php echo $fetch['img4']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file4" id="file" />  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name4" value="<?php echo $fetch['img4'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete4" value="DELETE"/>
			</td>
		</tr>
		
		<tr> 
			<td>Image-5</td>
			<td>
				<img src="<?php echo $fetch['img5']; ?>" alt="<?php echo $fetch['img5']; ?>" height="75" width="75" > 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file5" id="file" /> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name5" value="<?php echo $fetch['img5'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete5" value="DELETE"/>
			</td>
		</tr>
		
		<tr> 
			<td>Image-6</td>
			<td> 
				<img src="<?php echo $fetch['img6']; ?>" alt="<?php echo $fetch['img6']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file6" id="file" />  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name6" value="<?php echo $fetch['img6'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete6" value="DELETE"/>
			</td>
		</tr>
		
		<tr> 
			<td>Image-7</td>
			<td> 
				<img src="<?php echo $fetch['img7']; ?>" alt="<?php echo $fetch['img7']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file7" id="file" />  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name7" value="<?php echo $fetch['img7'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete7" value="DELETE"/>
			</td>
		</tr>
		<tr> 
			<td>Image-8</td>
			<td> 
				<img src="<?php echo $fetch['img8']; ?>" alt="<?php echo $fetch['img8']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file8" id="file" />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name8" value="<?php echo $fetch['img8'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete8" value="DELETE"/>			
			</td>
		</tr>
		<tr> 
			<td>Image-9</td>
			<td>
				<img src="<?php echo $fetch['img9']; ?>" alt="<?php echo $fetch['img9']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file9" id="file" /> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name9" value="<?php echo $fetch['img9'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete9" value="DELETE"/>				
			</td>
		</tr>
		<tr> 
			<td>Image-10</td>
			<td> 
				<img src="<?php echo $fetch['img10']; ?>" alt="<?php echo $fetch['img10']; ?>" height="75" width="75" >  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="file10" id="file" style="margin-top:10px;"/>  
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="name10" value="<?php echo $fetch['img10'];?>"/> 	
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="delete10" value="DELETE"/>
			</td>
		</tr>
                            <tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" value="Update" onclick="return val(this.form)"  />
                          
                         </td>
                            </tr>
                           
                          </tbody>
                  </table>
               	</form>
                    
                   <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='property_list.php'" />
                  
                
                <br /><br />
    

          </div><!--content-->
                
            </div><!--maincontentinner-->
            
<?php include_once("footer.php"); ?>       
