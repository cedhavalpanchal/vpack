<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from e-bootstrap.com/html/jollyany/portfolio-gallery-4.html by HTTrack Website Copier/3.x [XR&CO'2010], Mon, 27 Apr 2015 11:46:54 GMT -->
<head>
  
  <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 

  <title>Shraddha Enterprise</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Bootstrap Styles -->
  <link href="css/bootstrap.css" rel="stylesheet">
  
  <!-- Styles -->
  <link href="style.css" rel="stylesheet">
  
  <!-- Carousel Slider -->
  <link href="css/owl-carousel.css" rel="stylesheet">
  
  <!-- CSS Animations -->
  <link href="css/animate.min.css" rel="stylesheet">
  
  <!-- Google Fonts -->
  <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Lato:400,300,400italic,300italic,700,700italic,900' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Exo:400,300,600,500,400italic,700italic,800,900' rel='stylesheet' type='text/css'>

  <!-- SLIDER ROYAL CSS SETTINGS -->
  <link href="royalslider/royalslider.css" rel="stylesheet">
  <link href="royalslider/skins/default-inverted/rs-default-inverted.css" rel="stylesheet">
  
  <!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
  <link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />
        
  <!-- Support for HTML5 -->
  <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!-- Enable media queries on older bgeneral_rowsers -->
  <!--[if lt IE 9]>
    <script src="js/respond.min.js"></script>  <![endif]-->

	<!-- Switcher Only -->
        <link rel="stylesheet" id="switcher-css" type="text/css" href="switcher/css/switcher.css" media="all" />
    <!-- END Switcher Styles -->
    
	<!-- Demo Examples -->
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/green.css" title="green" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/tael.css" title="tael" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/light-green.css" title="light-green" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/yellow.css" title="yellow" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/blue.css" title="blue" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/light-blue.css" title="light-blue" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/purple.css" title="purple" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/violet.css" title="violet" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="switcher/css/red.css" title="red" media="all" />        <link rel="alternate stylesheet" type="text/css" href="switcher/css/orange.css" title="orange" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="dark-style.css" title="dark" media="all" />
	<!-- END Demo Examples -->
    
</head>
<body>



    <!-- ADD Switcher -->
		
    <!-- END Switcher -->
    
	<?php include("header.php");?><!-- end header-style-1 -->

    <section class="post-wrapper-top jt-shadow clearfix">
		<div class="container">
			<div class="col-lg-12">
				<h2>Brochure</h2>
                <ul class="breadcrumb pull-right">
                    <li><a href="index-2.html">Home</a></li>
                    <li>Brochure</li>
                </ul>
			</div>
		</div>
	</section><!-- end post-wrapper-top -->
   
	<section class="white-wrapper">
    	<div class="container">
        	<div class="general-title">
            	<h2>Brochure</h2>
                <hr>
            </div><!-- end general title -->
		</div><!-- end container -->

		<div class="text-center clearfix">
			<nav class="portfolio-filter">
               <!-- <ul>
                    <li><a class="btn btn-primary" href="#" data-filter="*"><span></span>All</a></li>
                    <li><a class="btn btn-primary" href="#" data-filter=".photography">Photography</a></li>
                    <li><a class="btn btn-primary" href="#" data-filter=".app-design">App Design</a></li>
                    <li><a class="btn btn-primary" href="#" data-filter=".logo">Logo</a></li>
                </ul>-->
			</nav>
		</div><!-- end text-center --> 
            
		<div class="portfolio_wrapper padding-top">
			<div class="portfolio_item photography">
				<div class="entry">
					<img src="demos/1515.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->

			<div class="portfolio_item photography app-design">
				<div class="entry">
					<img src="demos/2.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
            
			<div class="portfolio_item app-design">
				<div class="entry">
					<img src="demos/3.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
            
			<div class="portfolio_item app-design">
				<div class="entry">
					<img src="demos/4.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
        
			<div class="portfolio_item photography">
				<div class="entry">
					<img src="demos/6.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->

			<div class="portfolio_item logo">
				<div class="entry">
					<img src="demos/8.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
            
			<div class="portfolio_item logo">
				<div class="entry">
					<img src="demos/11.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
            
			<div class="portfolio_item logo">
				<div class="entry">
					<img src="demos/10.jpg" alt="" class="img-responsive">
					<br>
						<div class="buttons">
							<a class="st btn btn-default" rel="bookmark" href="#">Download Brochure</a>
                            <h3></h3>
						</div><!-- end buttons -->
					<!-- end magnifier -->
				</div><!-- end entry -->
			</div><!-- end portfolio_item -->
		</div><!-- portfolio_wrapper -->
        
		<div class="clearfix"></div>
            
		
    </section><!-- end white-wrapper -->
    
<?php include("footer.php");?>
                </div><!-- end copyright-text -->
			</div><!-- end widget -->
			<!-- end large-7 --> 
        </div><!-- end container -->
    </div><!-- end copyrights -->
    
	<div class="dmtop">Scroll to Top</div>
        
  <!-- Main Scripts-->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/menu.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.parallax-1.1.3.js"></script>
  <script src="js/jquery.simple-text-rotator.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/custom-portfolio.js"></script>

    

  <!-- Demo Switcher JS -->
  <script type="text/javascript" src="switcher/js/fswit.js"></script>
  <script src="switcher/js/bootstrap-select.js"></script>
 
</body>

<!-- Mirrored from e-bootstrap.com/html/jollyany/portfolio-gallery-4.html by HTTrack Website Copier/3.x [XR&CO'2010], Mon, 27 Apr 2015 11:46:54 GMT -->
</html>