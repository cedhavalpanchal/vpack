<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
 include_once("header.php");
 
 if(isset($_REQUEST['delete_id']))
 {
	 $del_id = $_REQUEST['delete_id'];
	 $del = "delete from user_master where uid='$del_id' ";
	 if(mysqli_query($conn,$del) or die(mysqli_error($conn)))
	 {
		 header("location:userlist.php");
	 }
 }
 
if($_SESSION['type'] == 1)
{
}
else
{
	header("location:dashboard.php");
}
  ?>
<title>User List</title>
 
        <div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	<li><a href="adduser.php">New User</a></li>
                    <li class="current"><a href="userlist.php">User List</a></li>
                </ul><!--maintabmenu-->
                
                <div class="content" style="width:700px">
                
                 <div class="contenttitle radiusbottom0">
                    	<h2 class="image"><span>User List</span></h2>
                    </div><!--contenttitle-->
                   <!-- <div class="tableoptions">
                        <button class="deletebutton radius3">Delete Selected</button> &nbsp;
                    </div>tableoptions-->
                 <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                          
                        </colgroup>
                        <thead>
                            <tr>
                               <td class="head1">Name</td>
                               <td class="head0">Username</td>
                                <td class="head1">Password</td>
                                <td class="head0">Type</td>
                                <td class="head1" align="center">Action</td>
                                
                               
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                 <td class="head1">Name</td>
                                 <td class="head0">Username</td>
                                <td class="head1">Password</td>
                                <td class="head0">Type</td>
                                <td class="head1" align="center">Action</td>
                               
                            </tr>
                        </tfoot>
                        <tbody>
                        <?php 
						$sel = "select name,uid,username,password,type from user_master";
						$qry = mysqli_query($conn,$sel) or die(mysqli_error($conn));
						while($fetch = mysqli_fetch_array($qry))
						{
							if($fetch['type'] == 1)
							{
								$type = "Admin";
							}
							else
							{
								$type = "Employee";
							}
						?>
                            <tr>
                                <td><?php echo $fetch['name']; ?></td>
                                <td><?php echo $fetch['username']; ?></td>
                                <td><?php echo $fetch['password']; ?></td>
                                 <td><?php echo $type; ?></td>
                                <td class="center">
                                
                               
                                
                                <a href="userlist.php?delete_id=<?php echo $fetch['uid']; ?>" class="btn btn_trash"><span>Delete</span></a>
                                 </td>
                            </tr>
                            <?php
						}//while close
						?>
                           
                            </tbody></table>
                   
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>