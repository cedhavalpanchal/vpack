<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
 include_once("header.php");
 
 if(isset($_REQUEST['delete_id']))
 {
	 $del_id = $_REQUEST['delete_id'];
	 $del = "delete from inquiry where inquiry_id='$del_id' ";
	 if(mysqli_query($conn,$del) or die(mysqli_error($conn)))
	 {
		 header("location:inquirylist.php");
	 }
 }
 if(isset($_REQUEST['edit_id']))
 {
	 $v=$_REQUEST['edit_id'];
 }
 
  ?>
  <style type="text/css">
  /***** PAGINATION *****/
.pagination { list-style: none; overflow: hidden; }
.pagination  { display: inline-block; margin-right: 5px; }
.pagination .first, .pagination .previous, .pagination .next, .pagination .last { font-size: 18px; }
.pagination  a { display: block; font-weight: bold; border: 1px solid #ccc; padding: 5px 10px; color: #333; line-height: 21px; vertical-align: top; }
.pagination  a { background: #f7f7f7; -moz-border-radius: 2px; -webkit-border-radius: 2px; border-radius: 2px; }
.pagination  a:hover { cursor: pointer; text-decoration: none; background: #eee; }
.pagination  a.current { background: #333; color: #fff; border: 1px solid #272727; }
/*.pagination .first a:active, .pagination .previous a:active, .pagination .next a:active, .pagination .last a:active {
	background: #333; color: #fff; border 1px solid #272727;*/
}

  </style>
<title>Inquiry List</title>
 
        <div class="maincontent">
       	  <div class="maincontentinner" style="width:900px;">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	
                    <li class="current"><a href="inquirylist.php">inquiry List</a></li>
                   
                </ul><!--maintabmenu-->
                
                <div class="content" style="width:1000px">
                
                 <div class="contenttitle radiusbottom0">
                    	<h2 class="image"><span>Inquiry List</span></h2>
                        
                    </div><!--contenttitle-->
                  
                   <div class="tableoptions">
                       <form name="search" class="stdform" method="post">
			<!--<table cellpadding="0" cellspacing="0" border="0" class="stdtable">
				<tr>
				<td>Search By: </td>
				<td><select style="font-size:13px;" name="opt" id="opt" onChange="jsFunction()">
					<option <?php if(isset($_POST['opt']) && $_POST['opt'] == "All"){ echo 'selected="selected"';}?> >All</option>
					<option <?php if(isset($_POST['opt']) && $_POST['opt'] == "Name"){ echo 'selected="selected"';}?> >Name</option>
					<option <?php if(isset($_POST['opt']) && $_POST['opt'] == "Mobile No."){ echo 'selected="selected"';}?> >Mobile No.</option>
                    </select>
				</td>
				<td>Keyword:</td>
				<td><input class="mediuminput" autocomplete="off" name="key_word" type="text" size="100" value="" /></td>
				<td><input class="stdbtn btn_black radius2" name="next" type="submit" value="SEARCH" /></td>
				</tr>
			</table>-->
			</form> </div><!--tableoptions-->
                  
                 <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                        </colgroup>
                        <thead>
                            <tr>
                                <td class="head0">Sr no</td>
								<td class="head1">Name</td>
								<td class="head0">Phone Number</td>
								<td class="head1">Email</td>
								<td class="head0">message</td>
								<td class="head0">Product Name</td>
								<td class="head1">Quantity</td>
								<td class="head0">Action</td> 
								
                                
                                <!--<td class="head1 center">receiver_name</td>
								  <td class="head0">destination</td>-->
                                
                              
                               
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
							
								<td class="head0">Sr no</td>
								<td class="head1">Name</td>
								<td class="head0">Phone Number</td>
								<td class="head1">Email</td>
								<td class="head0">message</td>
								<td class="head0">Product Name</td>
								<td class="head1">Quantity</td>
							 <td class="head0">Action</td>     
                              
                               
                            </tr>
                        </tfoot>
                        <tbody>
						
                        <?php 
//						$sel = "select id,inquery_date,inquery_full_name,inquery_mobile_no,inquery_remark,next_inquery_date from inquery_master order by id DESC";
//						$qry = mysqli_query($conn,$sel) or die(mysqli_error($conn));
							
						require_once("paging.php");
		$sql= "select * from inquiry ";
		/*if(isset($_POST['opt'])){
			if($_POST['key_word'] != null){
				if($_POST['opt'] == "All"){ 
					$sql.=" where (member_name like '%".$_POST['key_word']."%' or member_id like '%".$_POST['key_word']."%' or member_mobile_no like '%".$_POST['key_word']."%' or member_mobile_no like '%".$_POST['key_word']."%' )";
				}
				if($_POST['opt'] == "Name"){ $sql.=" where inquery_full_name like '%".$_POST['key_word']."%'"; }
				if($_POST['opt'] == "Mobile No."){ $sql.=" where inquery_mobile_no='".$_POST['key_word']."'"; }
			}
		}*/
		$sql .= " order by inquiry_id DESC";
		//echo $sql;
		$res= mysqli_query($conn,$sql);
		$rowCount = 0;
		$total = 0;
		if($res){
		$rowCount = mysqli_num_rows($res);
		$total = $rowCount;}
		
		if(isset($_GET['page'])){
			$page =	$_GET['page'];
		}else{
			$page =	'1';
		}
		
		$limit = '50';
		$i=$limit*($page-1);
		
		$pager = Pager::getPagerData($total, $limit, $page);
		$offset	= $pager->offset;
		$limit	= $pager->limit;
		$page	= $pager->page;
		$sql = $sql . " limit $offset, $limit";
		if($rowCount > 0){
			$res = mysqli_query($conn,$sql);
		}
		if($rowCount < 1){
			//No records in the table.
			echo "<tr align='center'><td colspan='5'><strong> No Records Found !!! </strong> </td></tr>";
		}else{
					
						
						while($fatch = mysqli_fetch_array($res))
						{
						?>
                            <tr>
                                
                                <td><?php echo $rowCount; ?></td>
                              
                                
								<td><?php echo $fatch['name'] ?></td>
								<td><?php echo $fatch['phone_no'] ?></td>
								<td><?php echo $fatch['email'] ?></td>
								<td><?php echo $fatch['message'] ?></td>
								<td><?php echo $fatch['product_name']; ?> </td>
								<td><?php echo $fatch['quantity'] ?></td>
								
								
								
	
                               
							  
                                &nbsp;<!-- view -->
								<td class="center">
								
                                <?php
							   if($_SESSION['type'] == 1)
							   {
							   ?>
							   
                                &nbsp;
                                <a href="inquirylist.php?delete_id=<?php echo $fatch['inquiry_id']; ?>" class="btn btn_trash"><span>Delete</span></a>
                                 <?php
							   }
							   ?>
							   
                                 </td>
                            </tr>
                            <?php
							$rowCount--;
						}//while close
		}//else
						?>
                           
                            </tbody></table>
                     <?php
				//Show NEXT and PREVIOUS buttons and PAGE NUMBERS
	    echo '<center>';
		echo '<table class="pagination" align="center" style="width:auto;">
				<tr>
					<td class="first"><a href="'.$_SERVER['PHP_SELF'].'?page=1"><span>First</span></a></td>';
		if ($page <= 1)
			echo "<td class='first'><span>Previous</span></td>";
		else            
			echo "<td class='first'><a href='".$_SERVER['PHP_SELF']."'?page=".($page-1)."'><span>Previous</span></a></td>";
		echo "  ";
		for ($x=1;$x<=$pager->numPages;$x++){
			echo "  ";
			if ($x == $pager->page)
				echo "<td class='current'><span>$x</span></td>";
			else
				echo "<td class='current'><a href='".$_SERVER['PHP_SELF']."?page=".$x."'><span>".$x."</span></a></td>";
		}
		if($page == $pager->numPages) 
			echo "<td class='next'><span>Next</span></td>";
		else           
			echo "<td class='next'><a href='".$_SERVER['PHP_SELF']."?page=".($page+1)."'><span>Next</span></a></td>";
								
		echo "<td class='last'><a href='".$_SERVER['PHP_SELF']."?page=".$pager->numPages."'><span>Last</span></a></td>";
		echo "</tr></table>";
		
		echo "</center>";
				?>
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>