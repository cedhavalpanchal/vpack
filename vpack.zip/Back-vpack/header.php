<?php 

include_once("session.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<link rel="stylesheet" href="css/style.css" type="text/css" />
<!--[if IE 9]>
    <link rel="stylesheet" media="screen" href="css/ie9.css"/>
<![endif]-->

<!--[if IE 8]>
    <link rel="stylesheet" media="screen" href="css/ie8.css"/>
<![endif]-->

<!--[if IE 7]>
    <link rel="stylesheet" media="screen" href="css/ie7.css"/>
<![endif]-->
<script type="text/javascript" src="js/plugins/jquery-1.7.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery.flot.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery.flot.resize.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="js/custom/general.js"></script>
<script type="text/javascript" src="js/custom/dashboard.js"></script>
<script src="http://cdn.ckeditor.com/4.4.7/full/ckeditor.js"></script>

<!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
</head>

<body class="loggedin">

	<!-- START OF HEADER -->
	<div class="header radius3">
    	<div class="headerinner">
        	
            <a href="#">
            <label class="bebas" style="color:#FFF; font-size:32px;"> Vpack Machinery </label>
            <!--<img src="images/starlight_admin_template_logo_small.png" alt="" />--></a>
            
              
            <div class="headright">
            	<div class="headercolumn">&nbsp;</div>
            	<div id="searchPanel" class="headercolumn">
                	
                </div><!--headercolumn-->
            	
                <div id="userPanel" class="headercolumn">
                    <a href="#" class="userinfo radius2">
                        <img src="images/avatar.png" alt="" class="radius2" />
                        <span><strong><?php echo $_SESSION['uname']; ?></strong></span>
                    </a>
                    <div class="userdrop">
                        <ul>
                           
                            <li><a href="shutdown.php">Logout</a></li>
                        </ul>
                    </div><!--userdrop-->
                </div><!--headercolumn-->
            </div><!--headright-->
        
        </div><!--headerinner-->
	</div><!--header-->
    <!-- END OF HEADER -->
    
 <!-- START OF MAIN CONTENT -->
    <div class="mainwrapper">
     	<div class="mainwrapperinner">
         	
        <div class="mainleft">
          	<div class="mainleftinner">
            
              	<div class="leftmenu">
            		<ul>
                    	
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'record.php') or strpos($_SERVER['PHP_SELF'], 'recordlist.php')) echo 'class="current"';?>><a href="record.php" class="editor menudrop"><span>Category</span></a>
                        	<ul>
                            	<li><a href="record.php"><span>Add New Category</span></a></li>
                            	<li><a href="recordlist.php"><span>Category List</span></a></li>

                            </ul>
                        
                        </li>
						
						<!--  <li <?php if ( strpos($_SERVER['PHP_SELF'], 'sub_category.php') or strpos($_SERVER['PHP_SELF'], 'sub_categorylist.php')) echo 'class="current"';?>><a href="sub_category.php" class="editor menudrop"><span>Sub_Category</span></a>
                        	<ul>
                            	<li><a href="sub_category.php"><span>Add New Sub_Category</span></a></li>
                            	<li><a href="sub_categorylist.php"><span>Sub_Category List</span></a></li>

                            </ul>
                        
                        </li> -->
						
						<li <?php if ( strpos($_SERVER['PHP_SELF'], 'product.php') or strpos($_SERVER['PHP_SELF'], 'productlist.php')) echo 'class="current"';?>><a href="product.php" class="editor menudrop"><span>Product</span></a>
                        	<ul>
                            	<li><a href="product.php"><span>Add New PRODUCT</span></a></li>
                            	<li><a href="productlist.php"><span>PRODUCT List</span></a></li>

                            </ul>
                        
                        </li>
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'service.php') or strpos($_SERVER['PHP_SELF'], 'servicelist.php')) echo 'class="current"';?>><a href="service.php" class="editor menudrop"><span>Service</span></a>
                            <ul>
                                <li><a href="service.php"><span>Add New Service</span></a></li>
                                <li><a href="servicelist.php"><span>Service List</span></a></li>

                            </ul>
                        
                        </li>
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'slider.php') or strpos($_SERVER['PHP_SELF'], 'sliderlist.php')) echo 'class="current"';?>><a href="slider.php" class="editor menudrop"><span>Slider</span></a>
                            <ul>
                                <li><a href="slider.php"><span>Add New Slider</span></a></li>
                                <li><a href="sliderlist.php"><span>Slider List</span></a></li>

                            </ul>
                        
                        </li>
                         <li <?php if ( strpos($_SERVER['PHP_SELF'], 'add_client.php') or strpos($_SERVER['PHP_SELF'], 'list_client.php')) echo 'class="current"';?>><a href="add_client.php" class="editor menudrop"><span>Client</span></a>
                            <ul>
                                <li><a href="add_client.php"><span>Add New Client</span></a></li>
                                <li><a href="list_client.php"><span>Client List</span></a></li>

                            </ul>
                        
                        </li>
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'contactuslist.php') or strpos($_SERVER['PHP_SELF'], 'contactuslist.php')) echo 'class="current"';?>><a href="contactuslist.php" class="editor menudrop"><span>Contact us</span></a>
                            <ul>
                               
                                <li><a href="contactuslist.php"><span>Contact List</span></a></li>

                            </ul>
                        
                        </li>
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'inquirylist.php') or strpos($_SERVER['PHP_SELF'], 'inquirylist.php')) echo 'class="current"';?>><a href="inquirylist.php" class="editor menudrop"><span>Enquiry List</span></a>
                            <ul>
                               
                                <li><a href="inquirylist.php"><span>Enquiry List</span></a></li>

                            </ul>
                        
                        </li>
                    <!--      <li <?php if ( strpos($_SERVER['PHP_SELF'], 'qcontactlist.php') or strpos($_SERVER['PHP_SELF'], 'qcontactlist.php')) echo 'class="current"';?>><a href="qcontactlist.php" class="editor menudrop"><span>Quick Contact</span></a>
                            <ul>
                               
                                <li><a href="contactlist.php"><span>Quick Contact List</span></a></li>

                            </ul>
                        
                        </li> -->
							
                         <?php
							   if($_SESSION['type'] == 1)
							   {
							   ?>
                        <li <?php if ( strpos($_SERVER['PHP_SELF'], 'adduser.php') or strpos($_SERVER['PHP_SELF'], 'userlist.php')) echo 'class="current"';?>><a href="adduser.php" class="elements menudrop"><span>User</span></a>
                        	<ul>
                            	<li><a href="adduser.php"><span>Add New User</span></a></li>
                            	<li><a href="userlist.php"><span>User List</span></a></li>
                            </ul>
                        
                        </li>
                       
							   <?php
							   }
							   ?>
							   
                       
                    </ul>
                        
                </div><!--leftmenu-->
            	<div id="togglemenuleft"><a></a></div>
            </div><!--mainleftinner-->
        </div><!--mainleft-->
    
