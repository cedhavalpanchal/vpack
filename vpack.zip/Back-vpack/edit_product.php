<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php");

if(isset($_REQUEST['edit_id']))
{
 echo $id = $_GET['edit_id'];
 $sel = "SELECT * FROM product where product_id=$id";
 $qry = mysqli_query($conn,$sel) or die(mysqli_error($conn));
 while($fetch = mysqli_fetch_array($qry))
 {
	  

if(isset($_REQUEST['submit']))
{
	echo $fname=$fetch['image1'];
	echo $product_id=$_POST['product_id'];
	$product_name = $_POST['product_name'];

	$product_description = $_POST['product_description'];
	$features = $_POST['features'];
	
	
   
	
	
if($_FILES['image1']['name']=="")
		 {
			
			 $fname=$fetch['image1'];
			 $path1= $fname;
		 }
		 else{
			$fname=$_FILES['image1']['name'];
			$tmp=$_FILES['image1']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "pro_id".$product_id."image1".$ext;
	
			$path1="productimage/".$nfname;
							
			if(move_uploaded_file($tmp,$path1))	
			{
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
								}	
		 }
							
			/*if($_FILES['image2']['name']=="")
			{
						 
			
			 $fname=$fetch['image2'];
			 $path2=$fname;
		 
			}
			else
		    {
	   
			$fname=$_FILES['image2']['name'];
			$tmp=$_FILES['image2']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
						$nfname = "pro_id".$product_id."image2".$ext;
	
			$path2="productimage/".$nfname;
							
			if(move_uploaded_file($tmp,$path2))	
				{
				echo "File is Uploaded";
				}
							else{
								echo "File Not Uploaded";
								}	
	    	}
	
	
	if($_FILES['image3']['name']=="")
	{
		 	
			 $fname=$fetch['image3'];
			 $path3=$fname;
		 
	}
else		
		{
	   
			$fname=$_FILES['image3']['name'];
			$tmp=$_FILES['image3']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
						$nfname = "pro_id".$product_id."image3".$ext;
	
			$path3="productimage/".$nfname;
							
			if(move_uploaded_file($tmp,$path3))	
		    {
				echo "File is Uploaded";
			}
							else{
								echo "File Not Uploaded";
							   }	
		 }
	if(empty($_FILES['uploadfiles']['name']))
		{
			$path4="";
		}
		else{
			$fname=$_FILES['uploadfiles']['name'];
			$tmp=$_FILES['uploadfiles']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "pro_id".$image_id."uploadfiles".$ext;
			
			$path4="pdfimage/".$nfname;
			
			move_uploaded_file($tmp,$path4);
			
		
	
	
}
*/
	   
	echo  $update = "update product set product_name= '".$product_name."',image1='".$path1."',product_description= '".$product_description."',Features = '".$features."' where product_id=$id";
	
	//$update ="update product set product_name='$product_name',image1='$image1',image2='$image2',image3='$image3',product_description='$product_description',Features='$features',Specification='$specification',Accessories='$accessories' where product_id='$id' ";
	
	if(mysqli_query($conn,$update))
	{
		header("Location:productlist.php");
		
	}
	
	
}
?>

<title>Edit Product Information</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>

 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		 
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		
<!------------------------------------------------------------->
<script>
$(function() {
	$( "#booking_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});
	
	$( "#delivery_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});

   
});
</script>

			
<div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	
                    <li class="current"><a href="sub_categorylist.php">Update Product Information</a></li>
                    <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='productlist.php'" />
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>EDIT Product</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)">
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
						  
                              <input type="hidden" id="product_id" name="product_id" placeholder="Enter Product Name "  class="mediuminput" required="required" value="<?php echo $fetch['product_id'] ?>" /> 
                               
                               <tr>
                               <th>Product <font color="#FF0000">*</font></th>
                               <td><input type="text" id="product_name" name="product_name" placeholder="Enter Product Name "  class="mediuminput" required="required" value="<?php echo $fetch['product_name'] ?>" /> 
                               </td>
                            </tr>
							<tr>
                              
                             <th></th>

								<td><img src="<?php echo $fetch['image1'] ?>" width="100" height="100"  /><?php echo $fetch['image1'] ?></td>
								 
								</tr>
							<tr>
                               <th>First Image <font color="#FF0000">*</font></th>
                               <td><input type="file" id="image1" name="image1" placeholder="Enter Image " class="mediuminput"  value="<?php echo $fetch['image1']; ?>" /> 
                               </td>
                            </tr>
							

						
							
							<tr>
                               <th>Product_Description <font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="product_description" name="product_description" placeholder="Enter Product_Description " class="ckeditor mediuminput" required="required"><?php echo $fetch['product_description'] ?>" </textarea> 
                               </td>
                            </tr>
                            <tr>
                               <th> Features<font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="features" name="features" placeholder="Enter Features" class="ckeditor mediuminput" required="required"><?php echo $fetch['Features'] ?></textarea> 
                               </td>
                            </tr>
							
							<tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" value="Update" onclick="return val(this.form)" />
                          
                         </td>
                            </tr>
						  
                           
                          </tbody>
                  </table>
               	</form>
                    
                   <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='productlist.php'" />
                  
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            
<?php  } }include_once("footer.php"); ?>       
