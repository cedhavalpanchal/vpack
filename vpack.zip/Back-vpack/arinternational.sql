-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2016 at 02:49 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arinternational`
--

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE IF NOT EXISTS `tracking` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `tracking_no` int(50) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `origin` varchar(50) NOT NULL,
  `booking_date` date NOT NULL,
  `receiver_name` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `no_of_box` int(13) NOT NULL,
  `weight` float NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` varchar(500) NOT NULL,
  `forwarding_no` double NOT NULL,
  `website` varchar(50) NOT NULL,
  `delivery_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tracking`
--

INSERT INTO `tracking` (`id`, `tracking_no`, `customer_name`, `origin`, `booking_date`, `receiver_name`, `destination`, `no_of_box`, `weight`, `type`, `status`, `forwarding_no`, `website`, `delivery_date`) VALUES
(1, 123456, 'Ankit', 'vadodara', '2016-05-12', 'PATEL', 'surat', 10, 5, 'Non Doc', 'xddhnk yjhn', 111111, 'www.neetai.com', '2016-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE IF NOT EXISTS `user_master` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1:admin,2:employee',
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`uid`, `name`, `username`, `password`, `type`, `status`) VALUES
(1, 'admin', 'arvind', 'arvind2016', 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
