<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php");
$im1=$im2=$im3=$im4=$im5=$im6=$im7=$im8=$im9=$im10="";
if(isset($_REQUEST['submit']))
{	
	$a=5001;
	// GENERATE UNIQUE ID WITH STRING AND NUMBER BEGGINE
	
		$last_temp="SELECT temp_id FROM property ORDER BY property_Id DESC LIMIT 1";
		$result_temp = mysqli_query($conn,$last_temp);
		
		while ($row = mysqli_fetch_array($result_temp)) 
		{
			$temp_id = $row['temp_id'];
			
		}
		$a=substr($temp_id,3,6);
		$a=$a+1;
		$str_temp="FHR".$a;
		
	// GENERATE UNIQUE ID WITH STRING AND NUMBER ENDING
	
	$category_id=$_REQUEST['cat'];
	$customer_master_id = $_REQUEST['customer_master_name'];
	$customer_mobile = $_REQUEST['customer_mobile'];
	$property_address = $_REQUEST['property_address'];
	$area_id = $_REQUEST['area_name'];
	$cat= $_REQUEST['cat'];
	$property_name= $_REQUEST['property_name'];
	$property_type= $_REQUEST['property_type'];
	$sq_feet= $_REQUEST['sq_feet'];
	$rooms= $_REQUEST['rooms'];
	$price = $_REQUEST['price'];
	$date=date('Y-m-d');
	$s='1';
	$details = $_REQUEST['details'];
	//$pf=$_REQUEST['check'];
	$check_popular=$_REQUEST['check_popular'];
	$check_feature=$_REQUEST['check_feature'];
	//echo "<script>alert('$check_popular')</script>";
	//echo "<script>alert('$check_feature')</script>";
	
	/*if($_FILES['myFirstFile']['type'] != 'image/jpeg'
	&&  $_FILES['myFirstFile']['type'] != 'image/jpg'
	&&  $_FILES['myFirstFile']['type'] != 'image/gif'
	&& $_FILES['myFirstFile']['type'] != 'image/png')
	{
		 $im1= "Please upload only Image file";
	}*/
	$last="SELECT property_id FROM property ORDER BY property_Id DESC LIMIT 1";
	$result = mysqli_query($conn,$last);
    while ($row = mysqli_fetch_array($result)) 
    {
        $property_id = $row['property_id'];
    }    
	
	$property_id=$property_id+1;

	$fname=$_FILES['file1']['name'];
	$tmp=$_FILES['file1']['tmp_name'];
	$ext =substr($fname,strrpos($fname,'.'));
	$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img1".$ext;
	
	$path1="gallery/".$nfname;
	
	move_uploaded_file($tmp,$path1);
	
		if(empty($_FILES['file2']['name']))
		{
			$path2="";
		}
		else{
			$fname=$_FILES['file2']['name'];
			$tmp=$_FILES['file2']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img2".$ext;
			
			$path2="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path2);
		}
	
		if(empty($_FILES['file3']['name']))
		{
			$path3="";
		}
		else{
		
				$fname=$_FILES['file3']['name'];
				$tmp=$_FILES['file3']['tmp_name'];
				$ext =substr($fname,strrpos($fname,'.'));
				$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img3".$ext;
				
				$path3="gallery/".$nfname;
				
				move_uploaded_file($tmp,$path3);
			}
	
		if(empty($_FILES['file4']['name']))
		{
			$path4="";
		}
		else{
				
				$fname=$_FILES['file4']['name'];
				$tmp=$_FILES['file4']['tmp_name'];
				$ext =substr($fname,strrpos($fname,'.'));
				$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img4".$ext;
				
				$path4="gallery/".$nfname;
				
				move_uploaded_file($tmp,$path4);
			}
	
			
		if(empty($_FILES['file5']['name']))
		{
			$path5="";
		}
		else{
						
				$fname=$_FILES['file5']['name'];
				$tmp=$_FILES['file5']['tmp_name'];
				$ext =substr($fname,strrpos($fname,'.'));
				$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img5".$ext;
					
				$path5="gallery/".$nfname;
					
				move_uploaded_file($tmp,$path5);
				
			}
	
	
		if(empty($_FILES['file6']['name']))
		{
			$path6="";
		}
		else{
			$fname=$_FILES['file6']['name'];
			$tmp=$_FILES['file6']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img6".$ext;
			
			$path6="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path6);
		}
	
	
	
		if(empty($_FILES['file7']['name']))
		{
			$path7="";
		}
		else{
			$fname=$_FILES['file7']['name'];
			$tmp=$_FILES['file7']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img7".$ext;
			
			$path7="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path7);
		}
	

		if(empty($_FILES['file8']['name']))
		{
			$path8="";
		}
		else{
			$fname=$_FILES['file8']['name'];
			$tmp=$_FILES['file8']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img8".$ext;
			
			$path8="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path8);
		}
	
	
		if(empty($_FILES['file9']['name']))
		{
			$path9="";
		}
		else{
			$fname=$_FILES['file9']['name'];
			$tmp=$_FILES['file9']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img9".$ext;
			
			$path9="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path9);
		}
	

		if(empty($_FILES['file10']['name']))
		{
			$path10="";
		}
		else{
			$fname=$_FILES['file10']['name'];
			$tmp=$_FILES['file10']['tmp_name'];
			$ext =substr($fname,strrpos($fname,'.'));
			$nfname = "cus_mobile-".$customer_mobile.",cityid-".$area_id.",cat_id-".$category_id.",pro_id-".$property_id."-img10".$ext;
			
			$path10="gallery/".$nfname;
			
			move_uploaded_file($tmp,$path10);
		}
	
	//echo $pf;
	if($check_popular==1)
	{
		
		$insert = "insert into property
		(temp_id,customer_name,customer_mobile,property_address,area_id,category_name,property_name,property_type ,sq_feet,rooms,price,property_description,img1,img2,img3,img4,img5,img6,img7,img8,img9,img10,date,status,popular,feature)	values	('$str_temp','$customer_master_id','$customer_mobile','$property_address','$area_id','$cat','$property_name','$property_type','$sq_feet','$rooms','$price','$details','$path1','$path2','$path3','$path4','$path5','$path6','$path7','$path8','$path9','$path10','$date','$s','$check_popular','$check_feature')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Detail succesfully added....');</script>";
			header("location:property_list.php?add=1");
		}
		else
		{
		echo "<script> alert('Invalid Data')</script>";
		}
	}
	else if( $check_feature==1)
	{
		
		$insert = "insert into property
		(temp_id,customer_name,customer_mobile,property_address,area_id,category_name,property_name,property_type ,sq_feet,rooms,price,property_description,img1,img2,img3,img4,img5,img6,img7,img8,img9,img10,date,status,popular,feature)	values	('$str_temp','$customer_master_id','$customer_mobile','$property_address','$area_id','$cat','$property_name','$property_type','$sq_feet','$rooms','$price','$details','$path1','$path2','$path3','$path4','$path5','$path6','$path7','$path8','$path9','$path10','$date','$s','$check_popular','$check_feature')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Detail succesfully added....');</script>";
			header("location:property_list.php?add=1");
		}
		else
		{
		echo "<script> alert('Invalid Data')</script>";
		}
	}
	else
	{
		$insert = "insert into property
		(temp_id,customer_name,customer_mobile,property_address,area_id,category_name,property_name,property_type ,sq_feet,rooms,price,property_description,img1,img2,img3,img4,img5,img6,img7,img8,img9,img10,date,status,popular,feature)	values	('$str_temp','$customer_master_id','$customer_mobile','$property_address','$area_id','$cat','$property_name','$property_type','$sq_feet','$rooms','$price','$details','$path1','$path2','$path3','$path4','$path5','$path6','$path7','$path8','$path9','$path10','$date','$s','$check_popular','$check_feature')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Property Detail succesfully added....');</script>";
			header("location:property_list.php?add=1");
		}
		else
		{
			echo "<script> alert('Invalid Data')</script>";
		}
	}
	  
}


 
  ?>
  
<title>Add Record</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>
		

<!-------------------------------------------------------------->

<script src="http://cdn.ckeditor.com/4.4.7/full/ckeditor.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />


<!------------------------------------------------------------->


<script language="javascript">
var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
function ValidateSingleInput(oInput) {

    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
			alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
</script>   

<!------------------------------------------------------------->
        
    <div class="maincontent">
       	<div class="maincontentinner" style="width:900px;">
            <ul class="maintabmenu multipletabmenu">
                <li class="current"><a href="add_property.php"> Add Property</a></li>
			</ul><!--maintabmenu-->
                
            <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
					<b>Enter Correct value</b>.
                </p>
            </div>

            <div class="content">
                <div class="contenttitle">
                    	<h2 class="form"><span>Add New Property</span></h2>
                </div><!--contenttitle-->
                <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)" >
					<table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                        <tbody>
							<tr>
								<td>Customer Name<font color="#FF0000">*</font></td>
								<td>
									<input type="text"  name="customer_master_name" placeholder="Customer Name" class="mediuminput"  title="Customer Name" required/>   
                                </td>
							</tr>
							
							<tr>
								<td> 
									Customer Mobile<font color="#FF0000">*</font>
								</td>
								<td>
									<input type="text"  name="customer_mobile" placeholder="Customer Mobile" class="mediuminput"  pattern= "[0-9]{10}" title="Plz Enter 10 Digit Only" required/>
								</td>
							</tr>
							
							<tr>
								<td>Property Address<font color="#FF0000">*</font></td>
								<td>
									<textarea   name="property_address" placeholder="Property Address" class="mediuminput"  title="Property Address" cols="80" rows="10" required></textarea>
								</td>
							</tr>
							
							<tr>
								<td>Area<font color="#FF0000">*</font></td>		
							
								<td>
							
								   <?php

										$query = 'SELECT * FROM area';
										$result = mysqli_query($conn,$query) or die(mysqli_error($conn));
										
										echo "<select name='area_name' id='pro_id' required/>";
										echo "<option value =''>Select City</option>";
										
										while ($row = mysqli_fetch_array($result))
										{
										  $city_name = $row['area_name']; 
										  $city_id = $row['area_id'];
										  echo "<option value='$city_id'>$city_name</option>";
										}

										echo "</select>";
									?>
								</td>
							</tr>
							
							<tr>
								<td>Category Name<font color="#FF0000">*</font></td>
								<td>
									<input type="radio" name="cat" value="buy" /> Buy &nbsp;&nbsp;
									<input type="radio" name="cat" value="rent"/> Rent&nbsp;&nbsp;
								</td>
							</tr>
						
							<tr>
								<td>Property Title<font color="#FF0000">*</font></td>
								<td>
									<input type="text"  name="property_name" size="39" maxlength="39" placeholder="Property Title" class="mediuminput"  title="Property Name" required/> 
								</td>
							</tr>
						
							<tr>
								<td>Property Type<font color="#FF0000">*</font></td>
								<td>
									<select name="property_type" >
										<option value="">--</option>
										<optgroup label="Residential">
											<option value="Apartment">Apartment</option>
											<option value="Bungalows">Bungalows</option>
											<option value="Duplex">Duplex</option>
											<option value="Tenement">Tenement</option>
											<option value="Plot">Plot</option>
											<option value="Villa">Villa</option>
											<option value="Penthouse">Penthouse</option>
											<option value="Ro house">Ro House</option>
										</optgroup>
										<optgroup label="Commercial">
											<option value="Shop">Shop</option>
											<option value="Office">Office</option>
											<option value="Showroom">Showroom</option>
										</optgroup>
									</select>
							
								</td>
							</tr>
								<td>Sq.feet</td>
								<td>
									<input type="text"  name="sq_feet" placeholder="Sq. Feet" class="mediuminput" pattern="[0-9]+" title="Enter only Number.."/> 
								</td>
							</tr>
						
							<tr>
								<td>Rooms</td>
								<td>
									<select name="rooms">
										<option value="">Select BHK</option>
										<option value="1BHK">1 BHK</option>
										<option value="2BHK">2 BHK</option>
										<option value="3BHK">3 BHK</option>
										<option value="4BHK">4 BHK</option>
										<option value="5BHK">5 BHK</option>
										<option value="6BHK">6 BHK</option>
										<option value="7BHK">7 BHK</option>
										<option value="8BHK">8 BHK</option>
									</select>
								</td>
							</tr>
							  
							<tr>
								<td>Price</td>
								<td>
									<input type="text"  name="price" placeholder="price" class="mediuminput" pattern="[0-9]+" title="Enter only Number.."> 
								</td> 
                            </tr>
							   
							<tr>
								<td>Property Description</td>
								<td>
									<textarea class="ckeditor" name="details"  placeholder="Enter Content" cols="80" rows="10"></textarea>  
								</td>
							</tr>
							
							<tr>
								<td>Popular/Feature</td>
								<td>
									<input type="checkbox" name="check_popular" value="1" /> Popular &nbsp;&nbsp;
									<input type="checkbox" name="check_feature" value="1"/> Feature&nbsp;&nbsp;
								</td>
							</tr>
							
							<tr>
								<td>Image-1<font color="#FF0000">*</font></td>
								<td>
									<input type="file" name="file1" id="file1" onblur="ValidateSingleInput(this);" required/>
									<p style="color:red;"><?php echo $im1;?></p>
								</td>
								
							</tr>
							<tr>
								<td>Image-2</td>
								<td>
									<input type="file" name="file2" id="file2"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im2;?></p>
								</td>
							</tr>
								  
							<tr>
								<td>Image-3</td>
								<td>
									<input type="file" name="file3" id="file3"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im3;?></p>
								</td>
							</tr>
								  
							<tr>
								<td>Image-4</td>
								<td>
									<input type="file" name="file4" id="file4"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im4;?></p>
								</td>
							</tr>  
							<tr>
								<td>Image-5</td>
								<td>
									<input type="file" name="file5" id="file5"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im5;?></p>
								</td>
							</tr>
							<tr>
								<td>Image-6</td>
								<td>
									<input type="file" name="file6" id="file6"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im6;?></p>
								</td>
							</tr>
							<tr>
								<td>Image-7</td>
								<td>
									<input type="file" name="file7" id="file7"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im7;?></p>
								</td>
							</tr>
							<tr>
								<td>Image-8</td>
								<td>
									<input type="file" name="file8" id="file8"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im8;?></p>
								</td>
							</tr>
							<tr>
								<td>Image-9</td>
								<td>
									<input type="file" name="file9" id="file9"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im9;?></p>
								</td>
							</tr>
							<tr>
								<td>Image-10</td>
								<td>
									<input type="file" name="file10" id="file10"onblur="ValidateSingleInput(this);" />
									<p style="color:red;"><?php echo $im10;?></p>
								</td>
							</tr>
								  
							<tr>
								<td colspan="2">
									<p class="stdformbutton">
										<input type="submit" name="submit" class="stdbtn btn_black radius2" id="submit" value="Save" onclick="return val(this.form)" /> 
										<input type="reset" class="reset radius2" value="Reset" />
									</p> 
								</td>
							</tr>
							 
						</tbody>
					</table>
				</form>
				
				<br /><br />

						
			</div><!--content-->
					
		</div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>