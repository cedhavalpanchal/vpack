<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");

include_once("header.php");
$image1=$image2=$image3=$image4="";

if(isset($_REQUEST['submit']))
{
	
	
	 
	
	$a=500;
	// GENERATE UNIQUE ID WITH STRING AND NUMBER BEGGINE
	
		$last_temp="SELECT product_id FROM product ORDER BY product_id DESC LIMIT 1";
		$result_temp = mysqli_query($conn,$last_temp);
		
		while ($row = mysqli_fetch_array($result_temp)) 
		{
			$product_id = $row['product_id'];
			
		}
		$a=$product_id;
		$a=$a+1;
		$str_temp="FHR".$a;
		
		/*$product_id=$_POST['product_id'];*/
		$sub_category_id = $_REQUEST['sub_category_id'];
	$product_name = $_REQUEST['product_name'];
	$image1=$_FILES['image1']['name'];
	/*$image2=$_FILES['image2']['name'];
	$image3=$_FILES['image3']['name'];
	$image4=$_FILES['uploadfiles']['name'];*/
	$product_description = $_REQUEST['product_description'];
	$features = $_REQUEST['features'];/*
	$specification = $_REQUEST['specification'];
	$accessories = $_REQUEST['accessories'];*/

		
		
		
	/*$check_popular=$_REQUEST['check_popular'];*/
	
	// GENERATE UNIQUE ID WITH STRING AND NUMBER ENDING
	
	
	/*if($_FILES['myFirstFile']['type'] != 'image/jpeg'
	&&  $_FILES['myFirstFile']['type'] != 'image/jpg'
	&&  $_FILES['myFirstFile']['type'] != 'image/gif'
	&& $_FILES['myFirstFile']['type'] != 'image/png')
	
	
	{
		 $image1= "Please upload only Image file";
		 $image2= "Please upload only Image file";
		 $image3= "Please upload only Image file";		 
	}*/
	$last="SELECT product_id FROM product ORDER BY product_id DESC LIMIT 1";
	$res = mysqli_query($conn,$last);
     $rowCount = 0;
        $total = 0;
        if($res){
        $rowCount = mysqli_num_rows($res);
        $total = $rowCount;
    }
        if($rowCount > 0){
           while ($row = mysqli_fetch_array($res)) 
    {
        $image_id = $row['product_id']+1;
    }
        }
        if($rowCount < 1){
            $image_id = 1;
        }

	$fname=$_FILES['image1']['name'];
	$tmp=$_FILES['image1']['tmp_name'];
	$ext =substr($fname,strrpos($fname,'.'));
	$nfname = "pro_id".$image_id."image1".$ext;
	
	$path1="productimage/".$nfname;
	
	move_uploaded_file($tmp,$path1);
	
		/*if(empty($_FILES['image2']['name']))
		{
			$path2="";
		}
		else{
			$fname1=$_FILES['image2']['name'];
			$tmp1=$_FILES['image2']['tmp_name'];
			$ext1 =substr($fname1,strrpos($fname1,'.'));
			$nfname1 = "pro_id".$image_id."image2".$ext1;
			
			$path2="productimage/".$nfname1;
			
			move_uploaded_file($tmp1,$path2);
		}
	
		if(empty($_FILES['image3']['name']))
		{
			$path3="";
		}
		else{
		
				$fname2=$_FILES['image3']['name'];
				$tmp2=$_FILES['image3']['tmp_name'];
				$ext2 =substr($fname2,strrpos($fname2,'.'));
				$nfname2 = "pro_id".$image_id."image3".$ext2;
				
				$path3="productimage/".$nfname2;
				
				move_uploaded_file($tmp2,$path3);
			}
		if(empty($_FILES['uploadfiles']['name']))
		{
			$path4="";
		}
		else{
			$fname3=$_FILES['uploadfiles']['name'];
			$tmp3=$_FILES['uploadfiles']['tmp_name'];
			$ext3 =substr($fname3,strrpos($fname3,'.'));
			$nfname3 = "pro_id".$image_id."uploadfiles".$ext3;
			
			$path4="pdfimage/".$nfname3;
			
			move_uploaded_file($tmp3,$path4);
			
		
	
	
}*/
	


	//echo $pf;
	
		
		$insert = "insert into product(category_id,product_name,image1,product_description,features)
		values('$sub_category_id','$product_name','$path1','$product_description','$features')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Product succesfully uploded....');</script>";
			header("location:productlist.php?add=1");
		}
		else
		{
		echo "<script> alert('Invalid Data')</script>";
		}
	  
}
	
	
	
	

  ?>
<title>Add Product</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>

<!------------------------------------------------------------->
<script>
$(function() {
	$( "#datepicker" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});
	
	$( "#delivery_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});

   
});
</script>
<script language="javascript">

function val(form) 

	{
		
		if(document.getElementById("fname").value == "")
   
   { 
   		alert("Please Insert Name"); // prompt user
		document.getElementById("fname").focus();
		return false;
   }   
   if(document.getElementById("address").value == "")
   
   { 
   		alert("Please Insert Comment"); // prompt user
		document.getElementById("address").focus();
		return false;
   }   
	 
	}
   
</script>

<script type="text/javascript">
   function resetForm(myFormId)
   {
       var myForm = document.getElementById(myFormId);

       for (var i = 0; i < myForm.elements.length; i++)
       {
           if ('submit' != myForm.elements[i].type && 'reset' != myForm.elements[i].type)
           {
               myForm.elements[i].checked = false;
               myForm.elements[i].value = '';
               myForm.elements[i].selectedIndex = 0;
           }
       }
   }
</script>
<!------------------------------------------------------------->
        
        <div class="maincontent">
       	  <div class="maincontentinner" style="width:900px;">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	<li class="current"><a href="product.php">New Product</a></li>
                    <li><a href="productlist.php">Product List</a></li>
                   
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>Add New Product</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)" id="myFormId" >
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
						 
						 
                </td>
							
						 
                           <tr>
                               <th>Choose Category <font color="#FF0000">*</font></th>
							   <?php $select_subcat = "select * from category order by category_id DESC";
							   $res= mysqli_query($conn,$select_subcat);?>
							  
                               <td><select id="sub_category_id" class="mediuminput" name="sub_category_id">
							   
									<option value="">--Select Sub_Category--</option>
								<?php	
								while($fetch = mysqli_fetch_array($res))
						{ ?>
							<option value="<?php echo $fetch['category_id']; ?>"><?php echo $fetch['category_name']; ?></option>
						<?php } ?>		</select> 
                               </td>
                            </tr>
							
                               <tr>
                               <th>Product_Name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="product_name" name="product_name" placeholder="Enter Product_Name " class="mediuminput" required="required" /> 
                               </td>
                            </tr>
							<tr>
                               <th>Product_Description <font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="product_name" name="product_description" placeholder="Enter Product_Name " class="ckeditor mediuminput" required="required"></textarea>
                               </td>
                            </tr>
							 <tr>
                               <th>Image <font color="#FF0000">*</font></th>
                               <td><input type="file" id="image1" name="image1" placeholder="Enter Image " class="mediuminput" required="required" /> 
                               </td>
                            </tr>
 <!-- 
							<tr>
                               <th>Second Image <font color="#FF0000">*</font></th>
                               <td><input type="file" id="image2" name="image2" placeholder="Enter Image " class="mediuminput" /> 
                               </td>
                            </tr>
							
							
							<tr>
                               <th>Third Image <font color="#FF0000">*</font></th>
                               <td><input type="file" id="image3" name="image3" placeholder="Enter Image " class="mediuminput" /> 
                               </td>
                            </tr> -->
							 <tr>
                             <!--   <th>PDf_File <font color="#FF0000"></font></th> -->
                               <td><input type="file" id="uploadfiles" name="uploadfiles"  value="uploadfiles" placeholder="Enter Image " class="mediuminput" style="display: none" /> 
                               </td>
                            </tr>
							
							<tr>
                               <th>Features <font color="#FF0000"></font></th>
                               <td><textarea type="text" id="features" name="features" placeholder="Enter Features " class="ckeditor mediuminput" ></textarea>
                               </td>
                            </tr><!-- 
							<tr>
                               <th>Specification<font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="specification" name="specification" placeholder="Enter Specification " class="ckeditor mediuminput" required="required"></textarea>
                               </td>
                            </tr>
							<tr>
                               <th>Accessories<font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="accessories" name="accessories" placeholder="Enter Accessories " class="ckeditor mediuminput" required="required"></textarea> 
                               </td>
                            </tr>
 
  -->
						   <!--<tr>
                               <th>Status<font color="#FF0000">*</font></th>
                                <td><span class="field"><textarea cols="20" id="status" placeholder="Enter Status" name="status" rows="5" class="mediuminput"></textarea></span> 
                               </td>
                            </tr>-->
						   <!--<tr>
                               <th>Origin <font color="#FF0000">*</font></th>
                               <td><input type="text" id="origin" name="origin" placeholder="Enter Origin " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Booking Date <font color="#FF0000">*</font></th>
                               <td><input type="text"  placeholder="MM/DD/YYYY" id="datepicker" name="booking_date" placeholder="Enter Booking Date " class="mediuminput" required="required" /> (MM/DD/YYYY)
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Reviser Name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="receiver_name" name="receiver_name" placeholder="Enter Reviser Name " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Destination <font color="#FF0000">*</font></th>
                               <td><input type="text" id="destination" name="destination" placeholder="Enter Destination " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>No of Boxes  <font color="#FF0000">*</font></th>
                               <td><input type="text" id="no_of_box" name="no_of_box" placeholder="Enter No of boxes  " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Weight<font color="#FF0000">*</font></th>
                               <td><input type="text" id="weight" name="weight" placeholder="Enter Number " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Type Doc / Non Doc<font color="#FF0000">*</font></th>
                               <td><input type="text" id="type" name="type" placeholder="Enter Number " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Status<font color="#FF0000">*</font></th>
                                <td><span class="field"><textarea cols="20" id="status" placeholder="Enter Status" name="status" rows="5" class="mediuminput"></textarea></span> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Forwarding No.<font color="#FF0000">*</font></th>
                                <td><input type="text" id="forwarding_no" name="forwarding_no" placeholder="Enter Forwarding No." class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
                            
							<!--<tr>
                               <th>Website<font color="#FF0000">*</font></th>
                                <td><input type="text" id="website" name="website" placeholder="Enter Website " class="mediuminput" required="required" />  
                               </td>
                            </tr>-->
                                                   
                            <!--<tr>
                               <th> Expected date of delivery  <font color="#FF0000">*</font></th>
                                <td><input type="text" id="delivery_date" name="delivery_date" placeholder="Enter Expected date of delivery" class="mediuminput" required="required" /> (MM/DD/YYYY)
                               </td>
                            </tr>-->
							<tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" id="submit" value="Save" onclick="return val(this.form)" /> 
                             <input type="reset" class="reset radius2" name="reset" value="Reset"/>
							 
                        </p> </td>
                            </tr>
                          </tbody>
                  </table>
               	</form>
                    
                   
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>