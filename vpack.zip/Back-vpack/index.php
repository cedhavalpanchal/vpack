<?php
session_start();
include_once("config.php");
if(isset($_SESSION['uid']))
{
	header("location:record.php");
}


if(isset($_REQUEST['submitform']))
{
	$user = $_POST['username'];
	$pass = $_POST['password'];
	
	$sel = "select username,type,uid from user_master where username='$user' and password='$pass' and status=1";
	$qry = mysqli_query($conn,$sel) or die(mysqli_error($conn));
	$cnt = mysqli_num_rows($qry);
	$fetch = mysqli_fetch_array($qry);
	$uname = $fetch['username'];
	$uid = $fetch['uid'];
	$type = $fetch['type'];
		
	if($cnt > 0)
	{
		$_SESSION['uname'] = $uname;
		$_SESSION['uid'] = $uid;
		$_SESSION['type'] = $type;
		
		header("location:record.php");
	}
	else
	{
		echo "<script>
               alert('Invalid Password or username');
                </script>";
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Login</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<script type="text/javascript" src="js/plugins/jquery-1.7.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('.loginform button').hover(function(){
		$(this).stop().switchClass('default','hover');
	},function(){
		$(this).stop().switchClass('hover','default');
	});
	
	$('#login').submit(function(){
		var u = jQuery(this).find('#username');
		if(u.val() == '') {
			jQuery('.loginerror').slideDown();
			u.focus();
			return false;	
		}
	});
	
	$('#login').submit(function(){
		var u = jQuery(this).find('#password');
		if(u.val() == '') {
			jQuery('.loginerror').slideDown();
			u.focus();
			return false;	
		}
	});
	
	
	$('#username').keypress(function(){
		jQuery('.loginerror').slideUp();
	});
});
</script>
<script type="text/javascript">
function errorfunction()
{
	function(){
		jQuery('.loginerror').slideUp();
	};
}
</script>
<!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
<style type="text/css">
.loginstyle { 
	background: #999; padding: 10px 20px; font-size: 18px; border: 0; letter-spacing: 1px; color: #333; width: 360px;
	-moz-box-shadow: 1px 1px 3px #222; -webkit-box-shadow: 1px 1px 3px #222; box-shadow: 1px 1px 3px #222; cursor: pointer;
}
</style>
</head>

<body class="login">

<div class="loginbox radius3">
	<div class="loginboxinner radius3">
    	<div class="loginheader">
    		<h1 class="bebas">Sign In</h1>
        	<div class="logo">
            <h2 style="font-size:36px; color:#FFF; text-align:right;">Vpack Machinery</h2>
            <!--<img src="images/starlight_admin_template_logo.png" alt="" />--></div>
    	</div><!--loginheader-->
        
        <div class="loginform">
        	<div class="loginerror"><p>Invalid username or password</p></div>
        	<form id="login" method="post">
            	<p>
                	<label for="username" class="bebas">Username</label>
                    <input type="text" id="username" name="username" class="radius2" />
                    <!--<select id="username" name="username" class="radius2">
                    <option>Admin</option>
                    <option>Member</option>
                    <option>Other</option>
                    </select>-->
                    
                </p>
                <p>
                	<label for="password" class="bebas">Password</label>
                    <input type="password" id="password" name="password" class="radius2" />
                </p>
                <p>
                	<input class="loginstyle" type="submit" name="submitform" value="Sign in" style="background: #999; padding: 10px 20px; font-size: 18px; border: 0; letter-spacing: 1px; color: #333; width: 360px;
	-moz-box-shadow: 1px 1px 3px #222; -webkit-box-shadow: 1px 1px 3px #222; box-shadow: 1px 1px 3px #222; cursor: pointer; border-radius:3px;" />
                  <!--  <button class="radius3 bebas">Sign in</button>-->
                </p>
                <!--<p><a href="#" class="whitelink small">Can't access your account?</a></p>-->
            </form>
        </div><!--loginform-->
    </div><!--loginboxinner-->
</div><!--loginbox-->

</body>

</html>
