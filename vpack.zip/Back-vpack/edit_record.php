<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php");

if(isset($_REQUEST['edit_id']))
{
 $id = $_GET['edit_id'];
 $sel = "select * from category where cat_id='$id'";
 $qry = mysqli_query($conn,$sel);
 $fetch = mysqli_fetch_array($qry);
}

if(isset($_REQUEST['submit']))
{
	
	
	$category_name = $_POST['cat_name'];
	
	
	
	$update ="update category set cat_name='$cat_name'";
	
if (mysqli_query($conn,$update) or die(mysqli_error($conn)))
	{
      header("location:recordlist.php?update=Record Updated Sucessfully");
	}
	else
	{
		echo "ERROR";
	}

}
?>

<title>Edit Record Information</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>

 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		 
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		
<!------------------------------------------------------------->
<script>
$(function() {
	$( "#booking_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});
	
	$( "#delivery_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});

   
});
</script>
<div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	
                    <li class="current"><a href="recordlist.php">Update Record Information</a></li>
                    <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='recordlist.php'" />
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>EDIT RECORD</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)">
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
						  
                              
                               <tr>
                               <th>Category_name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="category_name" name="cat_name" placeholder="Enter Category Name "  class="mediuminput" required="required" value="<?php echo $fetch['cat_name'] ?>" /> 
                               </td>
                            </tr>
							<tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" value="Update" onclick="return val(this.form)" />
                          
                         </td>
                            </tr>
						  
                           
                          </tbody>
                  </table>
               	</form>
                    
                   <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='recordlist.php'" />
                  
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            
<?php include_once("footer.php"); ?>       
