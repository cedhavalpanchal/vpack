<?php 
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php"); 

$id = $_GET['view_id'];
$mem_id = $_GET['mem_id'];
$sel = "select * from tracking where id=$id";
$qry = mysqli_query($conn,$sel);
$fetch = mysqli_fetch_array($qry);
?>
<title>View Member Information</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  .imgborder{
	  border:#CCC medium solid;
	  border-radius:3px;
  }
  </style>
  
  
  <script type="text/javascript">
function countfee()
{
	var discount = 1;
	
	var fee = document.getElementById("fee").value;
	 discount = document.getElementById("discount").value;
	
	var disc = parseFloat((fee*discount)/100);
	var totalfee = parseFloat(fee-disc);

	document.getElementById("totalfee").value = totalfee;
	
	var advance = document.getElementById("advance").value;
	
	var count = parseFloat(totalfee - advance);
	
	if( parseInt(advance) > parseInt(totalfee))
	{
		
		$(function() {
		$( "#alertdialog" ).dialog({
		modal: true,
		buttons: {
		Ok: function() {
		$( this ).dialog( "close" );
		}
		}
		});
		});
		
		document.getElementById('advance').value = '';
		document.getElementById('remaining').value = '';	
		document.getElementById('advance').focus();
	}
	else
	{
	document.getElementById('remaining').value = count;
	}
	
	if(totalfee == advance)
	{
		document.getElementById('installmentdate').disabled=true;
	}
	else
	{
		document.getElementById('installmentdate').disabled=false;
	}
}
</script>

		

<!------------------------------------------------------------->
        <div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu">
                	<li class="current"><a href="#">Member Information</a></li>
            </ul><!--maintabmenu-->
                
                <div class="content">
                
               <div class="contenttitle">
                    	<h2 class="form"><span>Information</span></h2>
                  </div> <!-- contenttitle-->
                 <form method="post">
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
                              
                               <tr>
                               <th>Tracking No. <font color="#FF0000">*</font></th>
                               <td><input type="text" id="tracking_no" name="tracking_no" placeholder="Enter Tracking No. "  class="mediuminput" required="required" value="<?php echo $fetch['tracking_no'] ?>" readonly /> 
                               </td>
                            </tr>
 
						   <tr>
                               <th>Customer Name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="customer_name" name="customer_name" placeholder="Enter Customer Name " class="mediuminput" required="required" value="<?php echo $fetch['customer_name'] ?>" readonly /> 
                               </td>
                            </tr>
						   
						   
                          
                            <tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	  <input type="button" class="stdbtn btn_black" style="float:right !important;" value="Back" onclick="location.href='recordlist.php'"  />
                          
                         </td>
                            </tr>
                           
                          </tbody>
                  </table>
                          <br />


               	</form>
                    
                              
                <br /><br />

                    
                </div><!--content-->
                
          </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>