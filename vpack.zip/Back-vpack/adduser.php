<?php 
ob_start();
session_start();
include_once("session.php");
include_once("config.php");
include_once("header.php");

if(isset($_REQUEST['submit']))
{
	$name =$_POST['name'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$type = $_POST['utype'];


	$insert ="insert into user_master
	(name,username,password,type)
	values
	('$name','$username','$password','$type')";
	if (mysqli_query($conn,$insert) or die(mysqli_error($conn)))
	{
		header("location:userlist.php");
	}
	else
	{
	echo "<script> alert('Invalid Data')</script>";
	}
}
if($_SESSION['type'] == 1)
{
}
else
{
	header("location:dashboard.php");
}
 ?>

<title>Add User</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>
        <!------------------------------------------------------------->

<div class="maincontent">
       	  <div class="maincontentinner">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	<li class="current"><a href="adduser.php">New User</a></li>
                    <li><a href="userlist.php">User List</a></li>
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>ADD NEW USER</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data">
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
                                                     
                            <tr>
                            <th> Name </th>
                            <td><input type="text" name="name" class="mediuminput"  />
                            </td>
                            </tr>
                            <tr>
                               <th>Username </th>
                               <td><input type="text" name="username" class="mediuminput"  /> 
                               </td>
                            </tr>
                            <tr>
                               <th>Password </th>
                               <td><input type="text" name="password" class="mediuminput"   />
                               </td>
                            </tr>
                         
                            
                            <tr>
                               <th>Type </th>
                               <td>
                               <span class="field">
                                <select name="utype">
                                	<option value="--">--Select--</option>
                                     <option value="1">Admin</option>
                                     <option value="2">Employee</option>
                                    
                                    </select>
                                    </span>
                               </td>
                            </tr>
                            <tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" value="Save" />
                            <input type="reset" class="reset radius2" value="Reset" />
                        </p> </td>
                            </tr>
                           
                          </tbody>
                  </table>
               	</form>
                    
                   
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            
<?php include_once("footer.php"); ?>       