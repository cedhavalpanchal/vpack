<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");

include_once("header.php");


if(isset($_REQUEST['submit']))
{
	
	
	
	
	$a=500;
	// GENERATE UNIQUE ID WITH STRING AND NUMBER BEGGINE
	
		$last_temp="SELECT * FROM client ORDER BY id DESC LIMIT 1";
		$result_temp = mysqli_query($conn,$last_temp);
		$id="";
		$imageid="";
		while ($row = mysqli_fetch_array($result_temp)) 
		{
			$id = $row['id'];
			
		}
		
		


		
		
	$image1=$_FILES['image']['name'];
	

		
		
		

	
	// GENERATE UNIQUE ID WITH STRING AND NUMBER ENDING
	
	
	/*if($_FILES['myFirstFile']['type'] != 'image/jpeg'
	&&  $_FILES['myFirstFile']['type'] != 'image/jpg'
	&&  $_FILES['myFirstFile']['type'] != 'image/gif'
	&& $_FILES['myFirstFile']['type'] != 'image/png')
	
	
	{
		 $image1= "Please upload only Image file";
		 $image2= "Please upload only Image file";
		 $image3= "Please upload only Image file";		 
	}*/
	$last="SELECT 	* FROM client ORDER BY id DESC LIMIT 1";
	$res = mysqli_query($conn,$last);
     $rowCount = 0;
        $total = 0;
        if($res){
        $rowCount = mysqli_num_rows($res);
        $total = $rowCount;
    }
        if($rowCount > 0){
           while ($row = mysqli_fetch_array($res)) 
    {
        $image_id = $row['id']+1;
    }
        }
        if($rowCount < 1){
            $image_id = 1;
        }


	$fname=$_FILES['image']['name'];
	$tmp=$_FILES['image']['tmp_name'];
	$ext =substr($fname,strrpos($fname,'.'));
	echo $nfname = "client_id".$image_id."image1".$ext;
	
	$path1="clientimage/".$nfname;
	
	move_uploaded_file($tmp,$path1);
	
		
		
	

	//echo $pf;
	
		echo $insert = "insert into client(image)
		values('$path1')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Image succesfully uploded....');</script>";
			header("location:list_client.php?add=1");
		}
		else
		{
		echo "<script> alert('Invalid Data')</script>";
		}
	
	

	  
}
	
	
	
	

  ?>
<title>Add Client</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>

<!------------------------------------------------------------->
<script>
$(function() {
	$( "#datepicker" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});
	
	$( "#delivery_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});

   
});
</script>
<script language="javascript">

function val(form) 

	{
		
		if(document.getElementById("fname").value == "")
   
   { 
   		alert("Please Insert Name"); // prompt user
		document.getElementById("fname").focus();
		return false;
   }   
   if(document.getElementById("address").value == "")
   
   { 
   		alert("Please Insert Comment"); // prompt user
		document.getElementById("address").focus();
		return false;
   }   
	 
	}
   
</script>

<script type="text/javascript">
   function resetForm(myFormId)
   {
       var myForm = document.getElementById(myFormId);

       for (var i = 0; i < myForm.elements.length; i++)
       {
           if ('submit' != myForm.elements[i].type && 'reset' != myForm.elements[i].type)
           {
               myForm.elements[i].checked = false;
               myForm.elements[i].value = '';
               myForm.elements[i].selectedIndex = 0;
           }
       }
   }
</script>
<!------------------------------------------------------------->
        
        <div class="maincontent">
       	  <div class="maincontentinner" style="width:900px;">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	<li class="current"><a href="client.php">New client</a></li>
                    <li><a href="list_client.php">Client List</a></li>
                   
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>Add New Client</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)" id="myFormId" >
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
						 
						 
                </td>
							
						 
                        
                                <tr>
                               <th>Image <font color="#FF0000">*</font></th>
                               <td><input type="file" id="image" name="image" placeholder="Enter Image " class="mediuminput" required="required" /> 
                               </td>
                            </tr>
							  
 
 
						 
							<tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" id="submit" value="Save" onclick="return val(this.form)" /> 
                             <input type="reset" class="reset radius2" name="reset" value="Reset"/>
							 
                        </p> </td>
                            </tr>
                          </tbody>
                  </table>
               	</form>
                    
                   
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>