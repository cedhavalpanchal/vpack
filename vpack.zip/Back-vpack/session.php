<?php
include_once("config.php");
if(isset($_SESSION['uid']))
{
	$uid = $_SESSION['uid'];
	
}
else
{
	header("location:index.php");
}
?>