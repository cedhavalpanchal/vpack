<?php
ob_start();
session_start();
include_once("session.php");
include_once("config.php");

include_once("header.php");


if(isset($_REQUEST['submit']))
{
	
	
	
	
	$a=500;
	// GENERATE UNIQUE ID WITH STRING AND NUMBER BEGGINE
	
		$last_temp="SELECT model_id FROM model ORDER BY model_id DESC LIMIT 1";
		$result_temp = mysqli_query($conn,$last_temp);
		
		while ($row = mysqli_fetch_array($result_temp)) 
		{
			$model_id = $row['model_id'];
			
		}
		$a=$model_id;
		$a=$a+1;
		$str_temp="FHR".$a;
		
		$model_id=$_POST['model_id'];
		
	$model_name = $_REQUEST['model_name'];
	
	$model_description = $_REQUEST['model_description'];
	

		
		
		
	$check_popular=$_REQUEST['check_popular'];
	
	
	$last="SELECT model_id FROM model ORDER BY model_id DESC LIMIT 1";
	$result = mysqli_query($conn,$last);
    while ($row = mysqli_fetch_array($result)) 
    {
        $image_id = $row['model_id']+1;
    }    
	
	$model_id=$model_id+1;

	
	


	//echo $pf;
	if($check_popular==1)
	{
		
		$insert = "insert into model(model_name,model_description) values('$model_name','$model_description')";
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Image succesfully uploded....');</script>";
			header("location:modellist.php?add=1");
		}
		else
		{
		echo "<script> alert('Invalid Data')</script>";
		}
	}
	
	else
	{
		$insert = "insert into model(model_name,model_description) values('$model_name','$model_description')";
		   
		   
		if(mysqli_query($conn,$insert) or die(mysqli_error($conn)))
		{
			echo" <script>alert('Image succesfully uploded....');</script>";
			header("location:modellist.php?add=1");
		}
		else
		{
			echo "<script> alert('Invalid Data')</script>";
		}
	}
	  
}
	
	
	
	

  ?>
<title>Add Model</title>
  <style type="text/css">
  th{
	  text-align:right;
	  width:200px;
  }
  </style>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="http://code.jquery.com/ui/1.10.0/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="js/timepicker/jquery-ui-timepicker-addon.css" />
		
        <script type="text/javascript" src="js/validation_js.js"></script>
        <script type="text/javascript" src="js/jquery_min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/timepicker/jquery-ui-sliderAccess.js"></script>

<!------------------------------------------------------------->
<script>
$(function() {
	$( "#datepicker" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});
	
	$( "#delivery_date" ).datepicker({
	changeMonth: true,
	changeYear: true, 
	showOn: "button",
	buttonImage: "images/icons/default/calendar.png",
	buttonImageOnly: true
	});

   
});
</script>
<script language="javascript">

function val(form) 

	{
		
		if(document.getElementById("fname").value == "")
   
   { 
   		alert("Please Insert Name"); // prompt user
		document.getElementById("fname").focus();
		return false;
   }   
   if(document.getElementById("address").value == "")
   
   { 
   		alert("Please Insert Comment"); // prompt user
		document.getElementById("address").focus();
		return false;
   }   
	 
	}
   
</script>

<script type="text/javascript">
   function resetForm(myFormId)
   {
       var myForm = document.getElementById(myFormId);

       for (var i = 0; i < myForm.elements.length; i++)
       {
           if ('submit' != myForm.elements[i].type && 'reset' != myForm.elements[i].type)
           {
               myForm.elements[i].checked = false;
               myForm.elements[i].value = '';
               myForm.elements[i].selectedIndex = 0;
           }
       }
   }
</script>
<!------------------------------------------------------------->
        
        <div class="maincontent">
       	  <div class="maincontentinner" style="width:900px;">
            	
                
              <ul class="maintabmenu multipletabmenu">
                	<li class="current"><a href="model.php">New Model</a></li>
                    <li><a href="modellist.php">Model List</a></li>
                   
                </ul><!--maintabmenu-->
                
                <div id="alertdialog" class="button_alert" title="Alert !" style="display:none;">
                <p>
                <b>Enter Correct value</b>.
                </p>
                </div>

                <div class="content">
                
                 <div class="contenttitle">
                    	<h2 class="form"><span>Add New Model</span></h2>
                    </div><!--contenttitle-->
                 <form method="post" class="stdform" enctype="multipart/form-data" name="form" onsubmit="return val(this.form)" id="myFormId" >
                 <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                         <tbody>
						 
						 
                </td>
							
						 
                         
							
                               <tr>
                               <th>Product_Name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="model_name" name="model_name" placeholder="Enter model_Name " class="mediuminput" required="required" /> 
                               </td>
                            </tr>
							<tr>
                               <th>model_Description <font color="#FF0000">*</font></th>
                               <td><textarea type="text" id="model_name" name="model_description" placeholder="Enter Model_Description " class="ckeditor mediuminput" required="required"></textarea>
                               </td>
                            </tr>
							
 
 
						   <!--<tr>
                               <th>Status<font color="#FF0000">*</font></th>
                                <td><span class="field"><textarea cols="20" id="status" placeholder="Enter Status" name="status" rows="5" class="mediuminput"></textarea></span> 
                               </td>
                            </tr>-->
						   <!--<tr>
                               <th>Origin <font color="#FF0000">*</font></th>
                               <td><input type="text" id="origin" name="origin" placeholder="Enter Origin " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Booking Date <font color="#FF0000">*</font></th>
                               <td><input type="text"  placeholder="MM/DD/YYYY" id="datepicker" name="booking_date" placeholder="Enter Booking Date " class="mediuminput" required="required" /> (MM/DD/YYYY)
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Reviser Name <font color="#FF0000">*</font></th>
                               <td><input type="text" id="receiver_name" name="receiver_name" placeholder="Enter Reviser Name " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Destination <font color="#FF0000">*</font></th>
                               <td><input type="text" id="destination" name="destination" placeholder="Enter Destination " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>No of Boxes  <font color="#FF0000">*</font></th>
                               <td><input type="text" id="no_of_box" name="no_of_box" placeholder="Enter No of boxes  " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Weight<font color="#FF0000">*</font></th>
                               <td><input type="text" id="weight" name="weight" placeholder="Enter Number " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Type Doc / Non Doc<font color="#FF0000">*</font></th>
                               <td><input type="text" id="type" name="type" placeholder="Enter Number " class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
							<!--<tr>
                               <th>Status<font color="#FF0000">*</font></th>
                                <td><span class="field"><textarea cols="20" id="status" placeholder="Enter Status" name="status" rows="5" class="mediuminput"></textarea></span> 
                               </td>
                            </tr>-->
							
							<!--<tr>
                               <th>Forwarding No.<font color="#FF0000">*</font></th>
                                <td><input type="text" id="forwarding_no" name="forwarding_no" placeholder="Enter Forwarding No." class="mediuminput" required="required" /> 
                               </td>
                            </tr>-->
                            
							<!--<tr>
                               <th>Website<font color="#FF0000">*</font></th>
                                <td><input type="text" id="website" name="website" placeholder="Enter Website " class="mediuminput" required="required" />  
                               </td>
                            </tr>-->
                                                   
                            <!--<tr>
                               <th> Expected date of delivery  <font color="#FF0000">*</font></th>
                                <td><input type="text" id="delivery_date" name="delivery_date" placeholder="Enter Expected date of delivery" class="mediuminput" required="required" /> (MM/DD/YYYY)
                               </td>
                            </tr>-->
							<tr>
                            	<td colspan="2"><p class="stdformbutton">
                        	 <input type="submit" name="submit" class="stdbtn btn_black radius2" id="submit" value="Save" onclick="return val(this.form)" /> 
                             <input type="reset" class="reset radius2" name="reset" value="Reset"/>
							 
                        </p> </td>
                            </tr>
                          </tbody>
                  </table>
               	</form>
                    
                   
                
                <br /><br />

                    
                </div><!--content-->
                
            </div><!--maincontentinner-->
            

<?php include_once("footer.php"); ?>